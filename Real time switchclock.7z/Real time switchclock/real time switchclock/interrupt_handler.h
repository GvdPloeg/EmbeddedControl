#ifndef _INTERRUPT_HANDLER_H_
#define _INTERRUPT_HANDLER_H_


void RT_output_handler(void);
void RTC_handler(void);

void Trigger_setter(void);
void Primer_handler(void);

extern volatile  uint16_t  PWM_frequency[], PWM_DutyCycle[];
extern volatile  uint32_t  PWM_modifier[];
extern uint8_t	 tick_day;
extern volatile  int s_update;
extern volatile  int default_refresh_flag;

#endif