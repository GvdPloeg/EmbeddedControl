/*
 * IncFile1.h
 *
 * Created: 21-9-2018 11:17:59
 *  Author: Anglclaw
 */ 


#ifndef MENU_H_
#define MENU_H_



int menuloop(void);


extern int PWM_setter_update(void);

extern volatile int trigger[];
extern volatile uint32_t primer_1[];
extern volatile uint32_t primer_0[];




#endif /* INCFILE1_H_ */