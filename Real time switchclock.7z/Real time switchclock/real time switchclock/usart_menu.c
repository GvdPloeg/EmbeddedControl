
#include "gpio.h"
#include "usart.h"
#include "print_funcs.h"
#include "init_header.h"
#include "interrupt_handler.h"





void init_usart_main_menu(void);
void usart_main_menu(void);
void init_usart_set_begin_times(void);
void init_usart_set_stop_times(void);
void usart_set_time(void);
void init_usart_set_weekday(void);
void usart_set_weekday(void);
int set_weekday_handler(int, int);
void usart_confirm_dialogue(void);



volatile  int usart_char;
volatile  uint8_t usart_flag;
int usart_state = 1;
int set_time = 1000;
int refresh_flag = 1;
int tselect = 0;
int buff_start = 0;
int buff_stop = 0;
volatile	uint8_t weekbuffer;



void usart_menu(void){
	if ((default_refresh_flag == 1)&&(usart_state == 2)){		//default usart menu gets refreshed every second to make sure it shows up when connecting to serial terminal
		usart_flag = 1;
		usart_state = 1;
		default_refresh_flag = 0;
	}
	if (refresh_flag == 1){
		usart_flag = 1;
		refresh_flag = 0;
	}
	if (usart_flag == 1){								
		switch(usart_state){
			case (1):
				init_usart_main_menu();					//prints static parts of usart main menu
				break;
			case (2):
				usart_main_menu();						
				break;
			case (3):
				init_usart_set_begin_times();			//prints static parts of begin times menu
				break;
			case (4):
				usart_set_time();						//set begin times input
				break;
			case (5):
				init_usart_set_stop_times();			//prints static parts of stop times menu
				break;
			case (6):
				usart_set_time();						//set stop times input
				break;
			case (7):
				init_usart_set_weekday();				//prints static parts of usart weekday menu
				break;
			case (8):
				usart_set_weekday();					//set weekdays input
				break;
			case (9):
				usart_confirm_dialogue();
				break;
		}
		usart_flag = 0;									
		usart_char = 0;									//clear usart char 
	}

}
	
void init_usart_main_menu(void){								//prints static parts of main usart menu
	print_dbg("\x1B[2J\x1B[;H");
	print_dbg("Main menu  \n\n\r");
	print_dbg("Pick a timer to set:\n\r");
	print_dbg("1. Set timer 1 \n\r");
	print_dbg("2. Set timer 2 \n\r");
	print_dbg("3. Set timer 3 \n\r");
	print_dbg("4. Set timer 4 \n\r");
	usart_state = 2;
}
	
	
void usart_main_menu()	{										//selects which timer to set up
	volatile int _input = usart_char - 48;						//convert input character to decimal value			
	if 	(_input == 1){
		tselect = 1;
		usart_state = 3;
		refresh_flag = 1;
	}
	if (_input == 2){
		tselect = 2;
		usart_state = 3;
		refresh_flag = 1;
	}
	if 	(_input == 3){
		tselect = 3;
		usart_state = 3;
		refresh_flag = 1;
	}
	if (_input == 4){
		tselect = 4;
		usart_state = 3;
		refresh_flag = 1;
	}
}


void init_usart_set_begin_times(){								//print static parts of begin times setting menu
	print_dbg("\x1B[2J\x1B[;H");
	print_dbg("Set BEGIN time for timer T");
	print_dbg_ulong(tselect);
	print_dbg(":\n\n\r");
	print_dbg("hh:mm:ss:mil\n\r");
	set_time = 1000;
	usart_state = 4;
}

void init_usart_set_stop_times(){								//print static parts of stop times setting menu
	print_dbg("\x1B[2J\x1B[;H");
	print_dbg("Set STOP time for timer T");
	print_dbg_ulong(tselect);
	print_dbg(":\n\n\r");
	print_dbg("hh:mm:ss:mil\n\r");
	set_time = 1000;
	usart_state = 6;
}



void usart_set_time(){											//the set time function is used to set both begin and end times
	volatile int _input = usart_char - 48;						// convert input character to decimal value
	static int buffhh = 0;
	static int buffmm = 0;
	static int buffss = 0;
	static int buffmillis = 0;
	switch(set_time){											//case state set_time is ordered by using 1000's for hours, 100's for minutes, 10's for seconds and single digits for milliseconds
		case (1000):									
			if ((_input >= 0)&&(_input <= 2)){					//first digit hours
				buffhh = _input *10;
				print_dbg_ulong(_input);
				if (_input == 2)
					set_time = 2001;	
				else
					set_time = 2000;	
			}
			break;
		case (2000):							
			if ((_input >= 0)&&(_input <= 9)){			//second digit hours
				buffhh = buffhh + _input;
				print_dbg_ulong(_input);
				print_dbg(":");
				set_time = 100;	
			}
			break;
		case (2001):							
			if ((_input >= 0)&&(_input <= 3)){			//alternate second digit hours input structure to prevent inputs higher than 24 hours
				buffhh = buffhh + _input;
				print_dbg_ulong(_input);
				print_dbg(":");
				set_time = 100;	
			}
			break;
		case (100):
			if ((_input >= 0)&&(_input <= 5)){			//first digit minutes
				buffmm = _input*10;
				print_dbg_ulong(_input);
				set_time = 200;	
			}
			break;
		case (200):
			if ((_input >= 0)&&(_input <= 9)){			//second digit minutes
				buffmm = buffmm + _input;
				print_dbg_ulong(_input);
				print_dbg(":");
				set_time = 10;	
			}
			break;
		case (10):
			if ((_input >= 0)&&(_input <= 5)){			//first digit seconds
				buffss = _input*10;
				print_dbg_ulong(_input);
				set_time = 20;	
			}
			break;
		case (20):
			if ((_input >= 0)&&(_input <= 9)){			//second digit seconds
				buffss = buffss + _input;			
				print_dbg_ulong(_input);
				print_dbg(":");
				set_time = 1;	
			}
			break;
		case (1):
			if ((_input >= 0)&&(_input <= 9)){			//first digit milliseconds			
				buffmillis = _input*100;
				print_dbg_ulong(_input);
				set_time = 2;	
			}
			break;
		case (2):
			if ((_input >= 0)&&(_input <= 9)){			//second digit milliseconds
				buffmillis = buffmillis + _input*10;
				print_dbg_ulong(_input);
				set_time = 3;	
			}
			break;
		case (3):
			if ((_input >= 0)&&(_input <= 9)){			//third digit milliseconds
				buffmillis = buffmillis + _input;
				print_dbg_ulong(_input);
				set_time = 0;	
				refresh_flag = 1;
			}
			break;
		case (0):
			print_dbg("\n\n\r");
			print_dbg("\n\rPress ENTER to confirm");
			print_dbg("\n\rOr press DELETE to cancel and retry");
			set_time = 10000;
			break;
		case (10000):
			if ((usart_state == 4) && ((usart_char == 46)||(usart_char == 126))){				//if setting begin times, return to setting begin times on pressing delete
				usart_state = 3;
				refresh_flag = 1;
			}
			if ((usart_state == 6) && ((usart_char == 46)||(usart_char == 126))){				//if setting stop times, return to setting stop times on pressing delete
				usart_state = 5;
				refresh_flag = 1;
			}
			if ((usart_state == 4) && (usart_char == 13)){										//when accepting input entering begin times, combine buffer variables to buff_start on pressing enter
				buff_start = buffhh*3600000+buffmm*60000+buffss*1000+buffmillis;
				usart_state = 5;
				refresh_flag = 1;
			}
			if  ((usart_state == 6) && (usart_char == 13)){										//when accepting input entering stop times, combine buffer variables to buff_stop on pressing enter
				buff_stop = buffhh*3600000+buffmm*60000+buffss*1000+buffmillis;
				usart_state = 7;
				refresh_flag = 1;
			}
			break;
	}
}


void init_usart_set_weekday(){											//prints static parts of usart weekday menu
	print_dbg("\x1B[2J\x1B[;H");
	print_dbg("Set days for T");
	print_dbg_ulong(tselect);
	print_dbg("\n\r");
	print_dbg("Use buttons 1 through 7 to set weekdays\n\r");
	print_dbg("Press ENTER to confirm\n\n\r");
	print_dbg("  1. Monday\n\r");
	print_dbg("  2. Tuesday\n\r");
	print_dbg("  3. Wednesday\n\r");
	print_dbg("  4. Thursday\n\r");
	print_dbg("  5. Friday\n\r");
	print_dbg("  6. Saturday\n\r");
	print_dbg("  7. Sunday\n\r");
	weekbuffer = 0;													//menu will always initialize with no days of the week being set active
	usart_state = 8;
}

void usart_set_weekday(){
	volatile int _input = usart_char - 48;	
	if ((_input <= 7)&&(_input >= 1)){
		if (_input == 1){
			print_dbg("\x1B[5;1H");										//sets the cursor on the correct position so a * can either be added or removed on corresponding weekday
		}
		if (_input == 2){
			print_dbg("\x1B[6;1H");										//sets the cursor on the correct position so a * can either be added or removed on corresponding weekday
		}
		if (_input == 3){
			print_dbg("\x1B[7;1H");										//sets the cursor on the correct position so a * can either be added or removed on corresponding weekday
		}
		if (_input == 4){
			print_dbg("\x1B[8;1H");										//sets the cursor on the correct position so a * can either be added or removed on corresponding weekday
		}
		if (_input == 5){
			print_dbg("\x1B[9;1H");										//sets the cursor on the correct position so a * can either be added or removed on corresponding weekday
		}
		if (_input == 6){
			print_dbg("\x1B[10;1H");									//sets the cursor on the correct position so a * can either be added or removed on corresponding weekday
		}
		if (_input == 7){
			print_dbg("\x1B[11;1H");									//sets the cursor on the correct position so a * can either be added or removed on corresponding weekday
		}
		weekbuffer = set_weekday_handler(_input, weekbuffer);
		print_dbg("\x1B[13;1H");
	}
	if (usart_char == 13){											//press enter to confirm
		usart_state = 9;											//next state = usart_confirm_dialogue
		refresh_flag = 1;
		weektrigger[tselect] = weekbuffer;
	}
	
}

int set_weekday_handler(int _input, int weekbuffer){					//the days of the week are stored in a bitwise array weekbuffer, with each bit respresenting a day
	if (((weekbuffer >> (_input-1)) & 1) == 0){						//when the weekday bit is currently inactive, it will be set to active
		weekbuffer = weekbuffer + (1 << (_input-1));				//weekbuffer is edited by adding a bitshifted 1 in the correct position
		print_dbg("*");												
	}
	else {															//when the weekday bit is currently active, it will be set to inactive
		weekbuffer = weekbuffer - (1 << (_input-1));				//weekbuffer is edited by substracting a bitshifted 1 in the correct position
		print_dbg(" ");
	}
	return weekbuffer;
}



void usart_confirm_dialogue(){											//the confirm dialogue is last step of the usart menu, pressing enter will push the buffer variables to the High speed switching clock
	print_dbg("\x1B[2J\x1B[;H");
	print_dbg("Press ENTER to confirm setting Timer ");
	print_dbg_ulong(tselect);
	print_dbg("\n\r");
	print_dbg("Press DELETE to abort");
	if (usart_char == 13){
		usart_state = 1;
		refresh_flag = 1;
		weektrigger[tselect] = weekbuffer;
		triggerstart[tselect] = buff_start;
		triggerstop[tselect] = buff_stop;
	}
	if ((usart_char == 46)||(usart_char == 126)){
		usart_state = 1;
		refresh_flag = 1;
	}
}