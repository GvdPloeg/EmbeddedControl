

#include "stdint.h"


#define _ASSERT_ENABLE_

#include "board.h"
#include "init_header.h"
#include "menu.h"


#if __GNUC__
__attribute__((__interrupt__))
#elif __ICCAVR32__
__interrupt
#endif



int main(void){
	init_main();
	menuloop();
}
