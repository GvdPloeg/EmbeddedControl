


#ifndef PWM_HANDLER_H_
#define PWM_HANDLER_H_



void PWM_update(int, int, int);
void PWM_init(void);




#endif /* PWM_HANDLER_H_ */