

#include "stdint.h"
#include "compiler.h"
#include "board.h"
#include "dip204.h"
#include "gpio.h"
#include "time.h"
#include "interrupt_handler.h"
#include "usart.h"
#include "init_header.h"
#include "gpio_handler.h"
#include "weekday.h"
#include "print_funcs.h"
#include "usart_menu.h"
#include "PWM_handler.h"


#define init_time_display 0
#define time_display 1
#define init_selection_menu 2
#define selection_menu 3
#define init_timeset_menu 4
#define timeset_menu 5
#define timeset_menu_e 6
#define weekday_menu 7
#define init_PWM_menu 8
#define PWM_menu 9
#define init_current_timeset_menu 10
#define current_timeset_menu 11






void f_init_time();
void f_time_display();
void f_display_time(char,char,char,char);
void f_init_selection_menu();
void f_time();
void clearclutter(char, char);
void printmenu(char, char, char);

void f_selection_menu();
void f_init_timeset_menu();
void f_timeset_menu();
void SetBeginTime();
void SetEndTime();
void f_weekday_menu();
void f_init_PWM_menu();
void f_PWM_menu();
void print_weekDay_menu(int ,int ,int ,int);
void print_weekday_menu(int);
void Set_PWM_freq(int);									
void Set_PWM_DuCy(int);
void Set_PWM_freq_MF(int);
void Set_PWM_DuCy_MF(int);
void Set_PWM_mode();
void Set_PWM_Select();
void PWM_HF_values();
void f_init_current_timeset_menu();
void f_current_timeset_menu();
void SetCurrentTime(int);

void PWM_trigger_update();
void print_day(int, int);
void set_weekday_trigger(int);
void split_triggers(int);
void debug_mode();

//int weekday_roll_over(int);
//void print_WeekDay(int);

int x=0, y=1, select=0, a=0, xprev=0;
int state=0;
int i=0;
//int tstart[]={0,0,0,0,0};
//int tstop[]={0,0,0,0,0};
	
//int tstart[]={0,6000,12000,18000,24000};
//int tstop[]={0,12000,18000,24000,30000};
	
volatile uint32_t hhstart[]={0,0,0,0,0}, mmstart[]={0,0,0,0,0}, ssstart[]={0,0,0,0,0}, millisstart[]={0,0,0,0,0};
volatile uint32_t Current_hh = 0, Current_mm = 0, Current_ss = 0, Current_millis = 0;
volatile uint8_t Current_weekday;
volatile static uint32_t hhstop[]={0,0,0,0,0}, mmstop[]={0,0,0,0,0}, ssstop[]={0,0,0,0,0}, millisstop[]={0,0,0,0,0};
volatile uint16_t PWM_frequency[]={0,1,1,1,1}, PWM_DutyCycle[]={0,50,50,50,50};
volatile uint32_t PWM_modifier[]={0,1000,1000,1000,1000};
	
static int PWM_select = 0;
volatile static int 	PWM_HF_frequency_state_pointer[] = {0,0,0,0,0};
volatile static int		PWM_modeselect[] = {0,1,1,1,1};
static int debugflag = 0;
static volatile  int trigger[];
	
bool init_week_clear;


//char cddstart[];



int menuloop(void)
{
	dip204_hide_cursor();
//	usart_flag=1;
	while(1){
		usart_menu();
		PWM_trigger_update();
		switch(state){
			case (init_time_display):
				clear_input_flags();
				f_init_time();
				state=time_display;
				break;
			case (time_display):
				f_time_display();
				break;
			case (init_selection_menu):
				f_init_selection_menu();
				break;
			case (selection_menu):
				f_selection_menu();
				break;
			case (init_timeset_menu):									//init timesetting menu
				f_init_timeset_menu();
				break;
			case (timeset_menu):										//timesetting menu
				f_timeset_menu();
				break;
			case (init_current_timeset_menu):									
				f_init_current_timeset_menu();
				break;
			case (current_timeset_menu):										
				f_current_timeset_menu();
				break;
			case (weekday_menu):
				f_weekday_menu();
				break;
			case (init_PWM_menu):
				f_init_PWM_menu();
				break;
			case (PWM_menu):
				f_PWM_menu();
				break;
		}
		if(state==timeset_menu_e){
			state=timeset_menu;
		}
	}
}

void f_init_time(){
	dip204_clear_display();
	if (debugflag == 8){
		dip204_set_cursor_position(xpos0,1);
		dip204_printf_string("Debug Mode");
	}
	dip204_set_cursor_position(xpos0+8,2);
	dip204_printf_string(":%02d", millis);
	dip204_set_cursor_position(xpos0-4,2);
	print_short_WeekDay(tick_day);
	dip204_set_cursor_position(xpos0,2);
	int tsbuffer = tick_ms/1000;
	struct tm *tmp = gmtime(&tsbuffer);
	dip204_printf_string("%02d:%02d:%02d", tmp->tm_hour,tmp->tm_min,tmp->tm_sec);
	clearclutter(xpos0+11,2);
}

void f_time_display(){
	dip204_set_cursor_position(xpos0+8,2);
	dip204_printf_string(":%02d", millis);
	if (s_update == 1){
		dip204_set_cursor_position(xpos0-4,2);
		print_short_WeekDay(tick_day);
		dip204_set_cursor_position(xpos0,2);
		int tsbuffer = tick_ms/1000;
		struct tm *tmp = gmtime(&tsbuffer);
		dip204_printf_string("%02d:%02d:%02d", tmp->tm_hour,tmp->tm_min,tmp->tm_sec);
		s_update = 0;
	}
	if(PushButtonFlag_2 == 1){
		state = init_selection_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_0 == 1){
		state = init_current_timeset_menu;
		clear_input_flags();
	}
	debug_mode();
}

void clearclutter (char x, char y){
	dip204_set_cursor_position(x,y);
	dip204_printf_string(" ");
}

void printmenu (char x, char y, char opcode){
	if (opcode==0){
		dip204_set_cursor_position(x,y);
		dip204_printf_string("*");
	}
	if (opcode==1){
		dip204_set_cursor_position(x,y);
		dip204_printf_string(">");
	}
	if (opcode==2){
		dip204_set_cursor_position(x,y);
		dip204_printf_string("<");
	}
	if (opcode==3){
		dip204_set_cursor_position(1,2);
		dip204_printf_string("Bgn");
		dip204_set_cursor_position(1,3);
		dip204_printf_string("End");
		dip204_set_cursor_position(6,4);
		dip204_printf_string("hh:mm:ss:mil");
		dip204_set_cursor_position(xpos0+12,2);
		dip204_printf_string("<");
		dip204_set_cursor_position(xpos0-1,2);
		dip204_printf_string(">");
	}
	if (opcode==4){
		dip204_set_cursor_position(x,y);
		if (PWM_modifier[i] == 1000000)
			dip204_printf_string("MHz");
		if (PWM_modifier[i] == 1000)
			dip204_printf_string("kHz");
		if (PWM_modifier[i] == 1)
			dip204_printf_string("Hz ");
	}
}

void f_init_selection_menu(){
	int x, y;
	
	dip204_clear_display();
	x=xmenu;
	for (y=1;y!=5;y++){
		split_triggers(y);
		dip204_set_cursor_position(x,y);	// Display timerselect menu
		if (menu_selector==1){
			dip204_printf_string("T%d %02d:%02d:%02d:%03d", y, hhstart[y],mmstart[y],ssstart[y],millisstart[y]);
		}
		if (menu_selector==0){
			dip204_printf_string("T%d %02d:%02d:%02d:%03d", y, hhstop[y],mmstop[y],ssstop[y],millisstop[y]);
		}
		if (menu_selector==2){
			dip204_printf_string("T%d ", y);
			int weekday;
			for ( weekday = 1; weekday <= 7; weekday++ ){
				if (((weektrigger[y] >> (weekday-1)) & 1) == 1){
					print_ultrashort_WeekDay(weekday);
					dip204_printf_string(" ");
				}
				else{
					dip204_printf_string("  ");
				}
			}
		}
		if (menu_selector==3){
			dip204_set_cursor_position(x,y);	
			dip204_printf_string("T%d %3d", y, PWM_frequency[y]);
			if (PWM_modifier[y] == 1000000)
				dip204_printf_string("MHz");
			if (PWM_modifier[y] == 1000)
				dip204_printf_string("kHz ");
			if (PWM_modifier[y] == 1)
				dip204_printf_string("Hz  ");
			dip204_set_cursor_position(xpos0+7,y);	
			dip204_printf_string("%3d", PWM_DutyCycle[y]);
			dip204_write_data(0x25);
		}
		if (timeselect[y]==1){
			printmenu(xpos0,y,0);
		}
	}
	if (menu_selector==1){							//print begintimes
		dip204_set_cursor_position(20,1);
		dip204_printf_string("B");
		dip204_set_cursor_position(20,2);
		dip204_printf_string("G");
		dip204_set_cursor_position(20,3);
		dip204_printf_string("N");
	}
	if (menu_selector==0){							//print endtimes 
		dip204_set_cursor_position(20,1);
		dip204_printf_string("E");
		dip204_set_cursor_position(20,2);
		dip204_printf_string("N");
		dip204_set_cursor_position(20,3);
		dip204_printf_string("D");
	}
	if (menu_selector==2){						//print days on which timers are active 
		dip204_set_cursor_position(20,1);
		dip204_printf_string("W");
		dip204_set_cursor_position(20,2);
		dip204_printf_string("E");
		dip204_set_cursor_position(20,3);
		dip204_printf_string("E");
		dip204_set_cursor_position(20,4);
		dip204_printf_string("K");
	}
	if (menu_selector==3){							//print endtimes 
		dip204_set_cursor_position(20,1);
		dip204_printf_string("P");
		dip204_set_cursor_position(20,2);
		dip204_printf_string("W");
		dip204_set_cursor_position(20,3);
		dip204_printf_string("M");
	}
	y=1;
	state = selection_menu;
}

void f_selection_menu(){
	x=1;
	printmenu(xpos0-4,y,0);
	debug_mode();
//	dip204_set_cursor_position(x,y);
	if((JoystickUpFlag == 1)&&(y!=1)){                                                      //up
		clearclutter(xpos0 - 4, y); 
		y--;
		clear_input_flags();
	}
	if((JoystickDownFlag == 1)&&(y!=4)){                                                      //down
		clearclutter(xpos0 - 4, y); 
		y++;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1 && (menu_selector == 0)){
		i = y;
		state = init_timeset_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1 && (menu_selector == 1)){
		i = y;
		state = init_timeset_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1 && (menu_selector == 3)){
		i = y;
		state = init_PWM_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1 && (menu_selector == 2)){
		i = y;
		dip204_clear_display();
		state = weekday_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_1 == 1){
		state = init_time_display;
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&(menu_selector==0)){
		menu_selector = 2;
		state = init_selection_menu;
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&(menu_selector==1)){
		menu_selector = 0;
		state = init_selection_menu;
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&(menu_selector==2)){
		menu_selector = 3;
		state = init_selection_menu;
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&(menu_selector==3)){
		menu_selector = 1;
		state = init_selection_menu;
		clear_input_flags();
	}
}

void f_init_timeset_menu(){
	dip204_clear_display();
	x=xpos0;
	xprev=0;
	state = timeset_menu;
	menu_selector = 1;
	dip204_set_cursor_position(1,1);
	dip204_printf_string("T%d", i);				//print timer ID
	printmenu(0,0,3);							//prints static menu parts
	if (timeselect[i]==1){
		printmenu(xpos0+15,2,0);
	}
	if (timeselect[i]==0){
		printmenu(xpos0+15,3,0);
	}
}

void f_timeset_menu(){
	dip204_set_cursor_position(xpos0,2);
	dip204_printf_string("%02d:%02d:%02d:%03d", hhstart[i],mmstart[i],ssstart[i],millisstart[i]);    //Display timesetting menu start time
	dip204_set_cursor_position(xpos0,3);
	dip204_printf_string("%02d:%02d:%02d:%03d", hhstop[i],mmstop[i],ssstop[i],millisstop[i]);     //Display timesetting menu stop time
	//scroll left using joystick
	if((JoystickLeftFlag == 1) &&(x!=xpos0)){                                         //left
		x--;
		if(x==xpos0+2)x--;                                           //skip unselectable parts
		if(x==xpos0+5)x--;                                           //skip unselectable parts
		if(x==xpos0+8)x--;
		clear_input_flags();
	}
	//scroll right using joystick
	if((JoystickRightFlag == 1) &&(x!=xpos0+11)){                                        //right
		x++;
		if(x==xpos0+2)x++;                                           //skip unselectable parts
		if(x==xpos0+5)x++;                                           //skip unselectable parts
		if(x==xpos0+8)x++;
		clear_input_flags();
	}
	//go back to previous menu using BUTTON 1
	if(PushButtonFlag_1 == 1){
		state = init_selection_menu;
		clear_input_flags();
	}
	//select start or stop timers using BUTTON 0
	if((PushButtonFlag_0 == 1)&&menu_selector==1){
		menu_selector=0;
		clearclutter(xpos0-1,2);
		printmenu(xpos0-1,3,1);
		clearclutter(xpos0+12,2);
		printmenu(xpos0+12,3,2);
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&menu_selector==0){
		menu_selector=1;
		clearclutter(xpos0-1,3);
		printmenu(xpos0-1,2,1);
		clearclutter(xpos0+12,3);
		printmenu(xpos0+12,2,2);
		clear_input_flags();
	}
	if (xprev!=x){				//erase prev cursor and print new
		clearclutter(xprev,1);
		printmenu(x,1,0);
		xprev=x;
	}
	if (PushButtonFlag_2 == 1){
		state = weekday_menu;
		init_week_clear = 1;
		clear_input_flags();
	}
	if(JoystickUpFlag == 1){
		if (menu_selector == 1){
			SetBeginTime(1);									// 1 = opcode up, 0 = opcode down
		}
		if (menu_selector == 0){
			SetEndTime(1);										// 1 = opcode up, 0 = opcode down
		}
		clear_input_flags();
	}
	if (JoystickDownFlag == 1){
		if (menu_selector == 1){
			SetBeginTime(0);									// 1 = opcode up, 0 = opcode down
		}
		if (menu_selector == 0){
			SetEndTime(0);										// 1 = opcode up, 0 = opcode down
		}
		clear_input_flags();
	}
	if(PushButtonFlag_1 == 1){
		state = timeset_menu_e;
		clear_input_flags();
	}
	triggerstart[i]	= hhstart[i]*hh_const+mmstart[i]*mm_const+ssstart[i]*ss_const+millisstart[i];
	triggerstop[i]	= hhstop[i]*hh_const+mmstop[i]*mm_const+ssstop[i]*ss_const+millisstop[i];
	//print_dbg_ulong(triggerstart[i]);
}


void f_init_current_timeset_menu(){
	split_triggers(0);	
	Current_weekday = tick_day;
	dip204_clear_display();
	dip204_set_cursor_position(xpos0-4,2);
	print_short_WeekDay(tick_day);
	x=xpos0;
	xprev=0;
	state = current_timeset_menu;
	menu_selector = 1;
	dip204_set_cursor_position(5,3);
//	printmenu(0,0,3);							//prints static menu parts
}


void f_current_timeset_menu(){
	dip204_set_cursor_position(xpos0,2);
	dip204_printf_string("%02d:%02d:%02d:%03d", Current_hh,Current_mm,Current_ss,Current_millis);    //Display timesetting menu start time
	//scroll left using joystick
	if((JoystickLeftFlag == 1) &&(x!=xpos0-4)){                                         //left
		x--;
		if(x==xpos0-1)x = xpos0 - 4;
		if(x==xpos0+2)x--;                                           //skip unselectable parts
		if(x==xpos0+5)x--;                                           //skip unselectable parts
		if(x==xpos0+8)x--;
		clear_input_flags();
	}
	//scroll right using joystick
	if((JoystickRightFlag == 1) &&(x!=xpos0+11)){                                        //right
		x++;
		if(x==xpos0-4)x = xpos0;
		if(x==xpos0+2)x++;                                           //skip unselectable parts
		if(x==xpos0+5)x++;                                           //skip unselectable parts
		if(x==xpos0+8)x++;
		clear_input_flags();
	}
	if (xprev!=x){				//erase prev cursor and print new
		clearclutter(xprev,1);
		printmenu(x,1,0);
		xprev=x;
	}
	if(JoystickUpFlag == 1){
		SetCurrentTime(1);									// 1 = opcode up, 0 = opcode down
		clear_input_flags();
	}
	if (JoystickDownFlag == 1){
		SetCurrentTime(0);									// 1 = opcode up, 0 = opcode down
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1){
		tick_ms	= Current_hh*hh_const+Current_mm*mm_const+Current_ss*ss_const+Current_millis;
		tick_day = Current_weekday;
		pmillis = tick_ms;
		millis = Current_millis;
		state = init_time_display;
		clear_input_flags();
	}
	if(PushButtonFlag_1 == 1){
		state = init_time_display;
		clear_input_flags();
	}
}

void SetCurrentTime(int opcode){
	if (opcode==1){
		if (x==xpos0 - 4){
			Current_weekday++;
			Current_weekday = weekday_roll_over(Current_weekday);
			dip204_set_cursor_position(xpos0-4,2);
			print_short_WeekDay(Current_weekday);
		}
		if(x==xpos0&&Current_hh<=13){                //uren +10
			Current_hh=Current_hh+10;
		}
		if(x==xpos0+1&&Current_hh<23){                   //uren +1
			Current_hh++;
		}
		//minuten
		if(x==xpos0+3&&Current_mm<=49){                //minuten +10
			Current_mm=Current_mm+10;
		}
		if(x==xpos0+4&&Current_mm<59){                 //minuten +1
			Current_mm++;
		}
		//seconden
		if(x==xpos0+6&&Current_ss<=49){                //seconden +10
			Current_ss=Current_ss+10;
		}
		if(x==xpos0+7&&Current_ss<59){               //seconden +1
			Current_ss++;
		}
		//milliseconden
		if(x==xpos0+9&&Current_millis<=899){               //milliseconden +100
			Current_millis=Current_millis+100;
		}
		if(x==xpos0+10&&Current_millis<=989){                //milliseconden +10
			Current_millis=Current_millis+10;
		}
		if(x==xpos0+11&&Current_millis<999){                   //milliseconden +1
			Current_millis++;
		}
	}
	if (opcode==0){
		if (x==xpos0-4){
			Current_weekday--;
			Current_weekday = weekday_roll_over(Current_weekday);
			dip204_set_cursor_position(xpos0-4,2);
			print_short_WeekDay(Current_weekday);
		}
		if(x==xpos0&&Current_hh>=10){                //uren -10
			Current_hh=Current_hh-10;
		}
		if(x==xpos0+1&&Current_hh>=1){                               //uren -1
			Current_hh--;
		}
		//minuten
		if(x==xpos0+3&&Current_mm>=10){                //minuten -10
			Current_mm=Current_mm-10;
		}
		if(x==xpos0+4&&Current_mm>=1){                               //minuten -1
			Current_mm--;
		}
		//seconden
		if(x==xpos0+6&&Current_ss>=10){                //seconden -10
			Current_ss=Current_ss-10;
		}
		if(x==xpos0+7&&Current_ss>=1){                               //seconden -1
			Current_ss--;
		}
		//milliseconden
		if(x==xpos0+9&&Current_millis>=100){               //milliseconden -100
			Current_millis=Current_millis-100;
		}
		if(x==xpos0+10&&Current_millis>=10){               //milliseconden -10
			Current_millis=Current_millis-10;
		}
		if(x==xpos0+11&&Current_millis>=1){					//milliseconden -1
			Current_millis--;
		}
	}
}


void SetBeginTime(int opcode){
	if (opcode==1){
		if(x==xpos0&&hhstart[i]<=13){                //uren +10
			hhstart[i]=hhstart[i]+10;
		}
		if(x==xpos0+1&&hhstart[i]<23){                   //uren +1
			hhstart[i]++;
		}
		//minuten
		if(x==xpos0+3&&mmstart[i]<=49){                //minuten +10
			mmstart[i]=mmstart[i]+10;
		}
		if(x==xpos0+4&&mmstart[i]<59){                 //minuten +1
			mmstart[i]++;
		}
		//seconden
		if(x==xpos0+6&&ssstart[i]<=49){                //seconden +10
			ssstart[i]=ssstart[i]+10;
		}
		if(x==xpos0+7&&ssstart[i]<59){               //seconden +1
			ssstart[i]++;
		}
		//milliseconden
		if(x==xpos0+9&&millisstart[i]<=899){               //milliseconden +100
			millisstart[i]=millisstart[i]+100;
		}
		if(x==xpos0+10&&millisstart[i]<=989){                //milliseconden +10
			millisstart[i]=millisstart[i]+10;
		}
		if(x==xpos0+11&&millisstart[i]<999){                   //milliseconden +1
			millisstart[i]++;
		}
	}
	if (opcode==0){
		if(x==xpos0&&hhstart[i]>=10){                //uren -10
			hhstart[i]=hhstart[i]-10;
		}
		if(x==xpos0+1&&hhstart[i]>=1){                               //uren -1
			hhstart[i]--;
		}
		//minuten
		if(x==xpos0+3&&mmstart[i]>=10){                //minuten -10
			mmstart[i]=mmstart[i]-10;
		}
		if(x==xpos0+4&&mmstart[i]>=1){                               //minuten -1
			mmstart[i]--;
		}
		//seconden
		if(x==xpos0+6&&ssstart[i]>=10){                //seconden -10
			ssstart[i]=ssstart[i]-10;
		}
		if(x==xpos0+7&&ssstart[i]>=1){                               //seconden -1
			ssstart[i]--;
		}
		//milliseconden
		if(x==xpos0+9&&millisstart[i]>=100){               //milliseconden -100
			millisstart[i]=millisstart[i]-100;
		}
		if(x==xpos0+10&&millisstart[i]>=10){               //milliseconden -10
			millisstart[i]=millisstart[i]-10;
		}
		if(x==xpos0+11&&millisstart[i]>=1){					//milliseconden -1
			millisstart[i]--;
		}
	}
}

void SetEndTime(int opcode){
	if (opcode==1){
		if(x==xpos0&&hhstop[i]<=13){                //uren +10
			hhstop[i]=hhstop[i]+10;
		}
		if(x==xpos0+1&&hhstop[i]<23){                   //uren +1
			hhstop[i]++;
		}
		//minuten
		if(x==xpos0+3&&mmstop[i]<=49){                //minuten +10
			mmstop[i]=mmstop[i]+10;
		}
		if(x==xpos0+4&&mmstop[i]<59){                 //minuten +1
			mmstop[i]++;
		}
		//seconden
		if(x==xpos0+6&&ssstop[i]<=49){                //seconden +10
			ssstop[i]=ssstop[i]+10;
		}
		if(x==xpos0+7&&ssstop[i]<59){               //seconden +1
			ssstop[i]++;
		}
		//milliseconden
		if(x==xpos0+9&&millisstop[i]<=899){               //milliseconden +100
			millisstop[i]=millisstop[i]+100;
		}
		if(x==xpos0+10&&millisstop[i]<=989){                //milliseconden +10
			millisstop[i]=millisstop[i]+10;
		}
		if(x==xpos0+11&&millisstop[i]<999){                   //milliseconden +1
			millisstop[i]++;
		}
	}
	if (opcode==0){
		if(x==xpos0&&hhstop[i]>=10){                //uren -10
			hhstop[i]=hhstop[i]-10;
		}
		if(x==xpos0+1&&hhstop[i]>=1){                               //uren -1
			hhstop[i]--;
		}
		//minuten
		if(x==xpos0+3&&mmstop[i]>=10){                //minuten -10
			mmstop[i]=mmstop[i]-10;
		}
		if(x==xpos0+4&&mmstop[i]>=1){                               //minuten -1
			mmstop[i]--;
		}
		//seconden
		if(x==xpos0+6&&ssstop[i]>=10){                //seconden -10
			ssstop[i]=ssstop[i]-10;
		}
		if(x==xpos0+7&&ssstop[i]>=1){                               //seconden -1
			ssstop[i]--;
		}
		//milliseconden
		if(x==xpos0+9&&millisstop[i]>=100){               //milliseconden -100
			millisstop[i]=millisstop[i]-100;
		}
		if(x==xpos0+10&&millisstop[i]>=10){               //seconden -10
			millisstop[i]=millisstop[i]-10;
		}
		if(x==xpos0+11&&millisstop[i]>=1){                                                                            //seconden -1
			millisstop[i]--;
		}
	}
}

void f_weekday_menu(){
	if (init_week_clear == 1){
		dip204_clear_display();
		init_week_clear = 0;
	}
	static int weekday = 1;
	if(JoystickDownFlag == 1){
		weekday++;
		weekday = weekday_roll_over(weekday);
		clear_input_flags();
		init_week_clear = 1;
	}
	if(JoystickUpFlag == 1){
		weekday--;
		weekday = weekday_roll_over(weekday);
		clear_input_flags();
		init_week_clear = 1;
	}
	if(PushButtonFlag_2 == 1){
		clear_input_flags();
		set_weekday_trigger(weekday);
	}
	if((PushButtonFlag_1 == 1) && (menu_selector != 2)){
		clear_input_flags();
		state = init_timeset_menu;
	}
	if((PushButtonFlag_1 == 1) && (menu_selector == 2)){
		clear_input_flags();
		state = init_selection_menu;
	}
	print_weekday_menu(weekday);
}

void print_weekday_menu(int weekday){
		int ypos = 2;
		dip204_set_cursor_position(3,ypos);
		dip204_printf_string(">");
		dip204_set_cursor_position(13,ypos);
		dip204_printf_string("<");
		dip204_set_cursor_position(4,ypos);
		print_day(weekday, ypos);
		ypos = 1; 
		dip204_set_cursor_position(4,ypos);
		print_day((weekday-1), ypos);
		ypos = 3;
		dip204_set_cursor_position(4,ypos);
		print_day((weekday+1), ypos);
		ypos = 4;
		dip204_set_cursor_position(4,ypos);
		print_day((weekday+2), ypos);
}

void print_day(int wbuffer, int ypos){
	wbuffer = weekday_roll_over(wbuffer);
	print_WeekDay(wbuffer);
	
	if (((weektrigger[i] >> (wbuffer-1)) & 1) == 1){
		dip204_set_cursor_position(2,ypos);
		dip204_printf_string("*");
	}
	else {
		dip204_set_cursor_position(2,ypos);
		dip204_printf_string(" ");
	}
}

void set_weekday_trigger(int weekday){								//The weekday trigger dictates on which days of the week the timer should be active
	if (((weektrigger[i] >> (weekday-1)) & 1) == 0){
		weektrigger[i] = weektrigger[i] + (1 << (weekday-1));	
	}
	else{
		weektrigger[i] = weektrigger[i] - (1 << (weekday-1));
	}
}

void split_triggers(int y){											//splits the trigger values so that they can be displayed seperately
	hhstart[y] = (triggerstart[y]/3600000);
	mmstart[y] = (triggerstart[y]-3600000*hhstart[y])/60000;
	ssstart[y] = (triggerstart[y]-3600000*hhstart[y]-mmstart[y]*60000)/1000;
	millisstart[y] = (triggerstart[y]-3600000*hhstart[y]-mmstart[y]*60000-ssstart[y]*1000);
	hhstop[y] = (triggerstop[y]/3600000);
	mmstop[y] = (triggerstop[y]-3600000*hhstop[y])/60000;
	ssstop[y] = (triggerstop[y]-3600000*hhstop[y]-mmstop[y]*60000)/1000;
	millisstop[y] = (triggerstop[y]-3600000*hhstop[y]-mmstop[y]*60000-ssstop[y]*1000);
	Current_hh = (tick_ms/3600000);
	Current_mm = (tick_ms-3600000*Current_hh)/60000;
	Current_ss = (tick_ms-3600000*Current_hh-Current_mm*60000)/1000;
	Current_millis = (tick_ms-3600000*Current_hh-Current_mm*60000-Current_ss*1000);
}

void f_init_PWM_menu(){
	dip204_clear_display();
	dip204_set_cursor_position(1,1);
	dip204_printf_string("T%d", i);				//print timer ID
	dip204_set_cursor_position(4,1);
	switch (PWM_modeselect[i]){
		case(0):
		dip204_printf_string("LF Mode");
		break;
		case(1):
		dip204_printf_string("MF Mode");
		break;
		case(2):
		dip204_printf_string("HF Mode");
		break;		
	}
		if (PWM_select == 0){
			clearclutter(xpos0-4,3);
			dip204_set_cursor_position(xpos0-4,2);
			dip204_printf_string("*");
		}
		else {
			clearclutter(xpos0-4,2);
			dip204_set_cursor_position(xpos0-4,3);
			dip204_printf_string("*");
		}

		

	dip204_set_cursor_position(xpos0-3,2);
	dip204_printf_string("Frequency: %03d", PWM_frequency[i]);
	printmenu(17,2,4);
	dip204_set_cursor_position(xpos0-3,3);
	dip204_printf_string("DutyCycle: %03d", PWM_DutyCycle[i]);
	dip204_write_data(0x25);
	x=xpos0+8;
	xprev=0;
	state = PWM_menu;
}

void f_PWM_menu(){
	//PWM_update(i-1, PWM_frequency[i]*PWM_modifier[i], PWM_DutyCycle[i]);
	dip204_set_cursor_position(xpos0+8,2);
	dip204_printf_string("%03d", PWM_frequency[i]);  
	dip204_set_cursor_position(xpos0+8,3);
	dip204_printf_string("%03d", PWM_DutyCycle[i]);  
	switch(PWM_modeselect[i]){
		//PWM_modeselect in LF mode
		case(0):																	
			if((JoystickRightFlag == 1) &&(x!=xpos0+10)){                                        //right
			x++;
			clear_input_flags();
			}
			if((JoystickLeftFlag == 1) &&(x!=xpos0+8)){                                         //left
				x--;
				clear_input_flags();
			}
				if(JoystickUpFlag == 1){
			if (PWM_select == 0){
					Set_PWM_freq(1);									// 1 = opcode up, 0 = opcode down
				}
				if (PWM_select == 1){
					Set_PWM_DuCy(1);										// 1 = opcode up, 0 = opcode down
				}
				clear_input_flags();
			}
			if (JoystickDownFlag == 1){
				if (PWM_select == 0){
					Set_PWM_freq(0);									// 1 = opcode up, 0 = opcode down
				}
				if (PWM_select == 1){
					Set_PWM_DuCy(0);										// 1 = opcode up, 0 = opcode down
				}
				clear_input_flags();
			}
			if (xprev!=x){											//erase prev cursor and print new
				clearclutter(xprev,1);
				printmenu(x,1,0);
				xprev=x;
			}
			break;
		//PWM_modeselect in MF mode
		case(1):
			if(JoystickUpFlag == 1){
				if (PWM_select == 0){
					Set_PWM_freq_MF(1);									// 1 = opcode up, 0 = opcode down
				}
				if (PWM_select == 1){
					Set_PWM_DuCy(1);										// 1 = opcode up, 0 = opcode down
				}
				clear_input_flags();
			}
			if (JoystickDownFlag == 1){
				if (PWM_select == 0){
					Set_PWM_freq_MF(0);									// 1 = opcode up, 0 = opcode down
				}
				if (PWM_select == 1){
					Set_PWM_DuCy(0);										// 1 = opcode up, 0 = opcode down
				}
				clear_input_flags();
			}
			break;
		//PWM_modeselect in HF mode
		case(2):
			if(JoystickUpFlag == 1){
				PWM_HF_frequency_state_pointer[i]++;
			}
			if (JoystickDownFlag == 1){
				PWM_HF_frequency_state_pointer[i]--;
			}
			clear_input_flags();
			PWM_HF_values();
			break;
		}
	if(PushButtonFlag_1 == 1){
		state = init_selection_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1){
		Set_PWM_mode();
		clear_input_flags();
	}
	if(PushButtonFlag_0 == 1){
		Set_PWM_Select();
		clear_input_flags();
	}
	PWM_trigger_update();
}


void Set_PWM_freq_MF(int opcode){
	if (opcode==1){
			if(PWM_frequency[i]<=90){      
				if(PWM_frequency[i]<=9){
					PWM_frequency[i]=PWM_frequency[i]++;
				}          
				else {
					PWM_frequency[i]=PWM_frequency[i]+10;
				}
			}
	}
	if (opcode==0){
		if(PWM_frequency[i] != 1){
			if(PWM_frequency[i]>10){                
				PWM_frequency[i]=PWM_frequency[i]-10;
			}
			else{
				PWM_frequency[i]=PWM_frequency[i]--;
			}
		}
	}
}

void Set_PWM_freq(int opcode){
	if (opcode==1){
			if(x==xpos0+8&&PWM_frequency[i]<=899){                
				PWM_frequency[i]=PWM_frequency[i]+100;
			}
			if(x==xpos0+9&&PWM_frequency[i]<=989){                
				PWM_frequency[i]=PWM_frequency[i]+10;
			}
			if(x==xpos0+10&&PWM_frequency[i]<=998){                   
				PWM_frequency[i]++;
			}
	}
	if (opcode==0){
			if(x==xpos0+8&&PWM_frequency[i]>=101){                
				PWM_frequency[i]=PWM_frequency[i]-100;
			}
			if(x==xpos0+9&&PWM_frequency[i]>=11){                
				PWM_frequency[i]=PWM_frequency[i]-10;
			}
			if(x==xpos0+10&&PWM_frequency[i] != 1){                   
				PWM_frequency[i]--;
			}
	}
}

void PWM_HF_values(){
	//int state_pointer = 
	switch(PWM_HF_frequency_state_pointer[i]){
		case (0):
			PWM_frequency[i] = 100;
			PWM_modifier[i] = 1000;
			break;
		case (1):
			PWM_frequency[i] = 200;
			PWM_modifier[i] = 1000;
			break;
		case (2):
			PWM_frequency[i] = 300;
			PWM_modifier[i] = 1000;
			break;
		case (3):
			PWM_frequency[i] = 400;
			PWM_modifier[i] = 1000;
			break;
		case (4):
			PWM_frequency[i] = 500;
			PWM_modifier[i] = 1000;
			break;
		case (5):
			PWM_frequency[i] = 600;
			PWM_modifier[i] = 1000;
			break;
		case (6):
			PWM_frequency[i] = 750;
			PWM_modifier[i] = 1000;
			break;
		case (7):
			PWM_frequency[i] = 1;
			PWM_modifier[i] = 1000000;
			break;
		case (8):
			PWM_frequency[i] = 2;
			PWM_modifier[i] = 1000000;
			break;
		case (9):
			PWM_frequency[i] = 3;
			PWM_modifier[i] = 1000000;
			break;
		case (10):
			PWM_frequency[i] = 4;
			PWM_modifier[i] = 1000000;
			break;
		case (11):
			PWM_frequency[i] = 6;
			PWM_modifier[i] = 1000000;
			break;
	}
	printmenu(17,2,4);
}

void Set_PWM_DuCy(int opcode){
	if (opcode==1){
		if(PWM_DutyCycle[i]!=90){
			PWM_DutyCycle[i]=PWM_DutyCycle[i]+10;
		}
	}
	if (opcode==0){
		if(PWM_DutyCycle[i]!=10){
			PWM_DutyCycle[i]=PWM_DutyCycle[i]-10;
		}
	}
}


void Set_PWM_mode(){
	static int PWM_freq_LF_mem = 100;
	static int PWM_freq_MF_mem = 10;
	static int PWM_freq_HF_mem = 1;
	switch (PWM_modeselect[i]){
		case(0):								//LF mode
			PWM_freq_LF_mem = PWM_frequency[i];
			PWM_frequency[i] = PWM_freq_MF_mem;
			PWM_modeselect[i] = 1;				//change to MF mode
			PWM_modifier[i] = 1000;
			//if (PWM_frequency[i] >= 100){
				//PWM_frequency[i] = 100;
			//}
			PWM_frequency[i] = PWM_freq_MF_mem;
		break;
		case(1):								//MF mode
			PWM_freq_MF_mem = PWM_frequency[i];
			PWM_modeselect[i] = 2;				//change to HF mode
			PWM_DutyCycle[i] = 50;
			PWM_HF_frequency_state_pointer[i] = PWM_freq_HF_mem;
			PWM_HF_values();
		break;
		case(2):								//HF mode
			PWM_freq_HF_mem = PWM_HF_frequency_state_pointer[i];
			PWM_modeselect[i] = 0;				//change to LF mode
			PWM_modifier[i] = 1;
			PWM_frequency[i] = PWM_freq_LF_mem;
		break;
	}
	state = init_PWM_menu;
}

void Set_PWM_Select(){					//for dutycycle setting PWM_select = 1
	switch (PWM_select){				//for frequency setting PWM_select = 0
		case(0):
			PWM_select = 1;
			clearclutter(xpos0-4,2);
			clearclutter(xpos0+8,1);
			clearclutter(xpos0+9,1);
			clearclutter(xpos0+10,1);
			dip204_set_cursor_position(xpos0-4,3);
			dip204_printf_string("*");
			break;							
		case(1):
			PWM_select = 0;
			clearclutter(xpos0-4,3);
			dip204_set_cursor_position(xpos0-4,2);
			dip204_printf_string("*");
			break;
	}
}


void PWM_trigger_update(){
	static volatile int prevtrigger[] = {0,0,0,0,0};
	int k;
	for (k=1;k!=5;k++){
		if (trigger[k] != prevtrigger[k]){			//only write to PWM registers when a change is needed
			if (trigger[k] == 1){
			PWM_update(k-1, PWM_frequency[k]*PWM_modifier[k], PWM_DutyCycle[k]);
			}
			if (trigger[k] == 0){
			PWM_update(k-1, PWM_frequency[k]*PWM_modifier[k], 0);
			}
		}
		prevtrigger[k] = trigger[k];
	}
}


void debug_mode(){

	if(JoystickLeftFlag == 1){    
		clear_input_flags();
		debugflag++;
		if (debugflag == 8){
			int k;
			tick_ms = (23*hh_const+59*mm_const+55*ss_const);
			pmillis = tick_ms;
			millis = 0;
			for (k=1;k!=5;k++){
				PWM_frequency[k]=6,
				PWM_DutyCycle[k]=50;
				PWM_modifier[k]=1000000;
				triggerstart[k]=0;
				triggerstop[k]=(0*hh_const+1*mm_const+0*ss_const);
			}
			state = init_time_display;
		}
	}
}