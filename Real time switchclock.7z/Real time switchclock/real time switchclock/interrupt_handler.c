
#include "board.h"
#include "stdint.h"
#include "init_header.h"
#include "gpio.h"
#include "weekday.h"
#include "menu.h"
#include "PWM.h"

void RT_output_handler(void);
void RTC_handler(void);
void Trigger_setter(void);
void Primer_handler();


volatile  int s_update;
volatile  int default_refresh_flag;
volatile  int trigger[] = {0,0,0,0,0};
volatile  uint32_t primer_1[] = {0,0,0,0,0};
volatile  uint32_t primer_0[] = {0,0,0,0,0};
uint8_t	  tick_day;



void RTC_handler(){															//the RTC_handler takes care of all events necessary to turn tick_ms into displayable time
	if (tick_ms-pmillis>=1) {
		millis=millis+tick_ms-pmillis;
		pmillisread = pmillis;
		pmillis=tick_ms;
		if (millis>=ss_const){												//millis should return to 0 every second
			millis=millis-ss_const;
			s_update = 1;													//the flag s_update causes the screen to update every second
			default_refresh_flag = 1;										//the flag default_refresh_flag causes the usart menu to be refreshed every second when it is in its begin screen
			if (tick_ms-dd_const<1){										//tick_ms should return to 0 after a full day has been completed
				tick_ms = tick_ms - dd_const;
				pmillis = 0;
				millis = 0;
				tick_day++;
				tick_day = weekday_roll_over(tick_day);						//rolls over the day of the week when at its last day
			}
		}
	}
}


//void Primer_handler(){
	//for (int k=1;k!=5;k++){
	//}
//}


void Trigger_setter(){
	if (trigger[1]==1){
		pwm_start_channels(1 << 0);  // Start channel 0.
	}
	else{
		pwm_stop_channels(1 << 0);  // Stop channel 0.
	}
	if (trigger[2]==1){
		pwm_start_channels(1 << 1);  // Start channel 1.
	}
	else{
		pwm_stop_channels(1 << 1);  // Stop channel 1.
	}
	if (trigger[3]==1){
		pwm_start_channels(1 << 2);  // Start channel 2.
	}
	else{
		pwm_stop_channels(1 << 2);  // Stop channel 2.
	}
	if (trigger[4]==1){
		pwm_start_channels(1 << 3);  // Start channel 3.
	}
	else{
		pwm_stop_channels(1 << 3);  // Stop channel 3.
	}
}

