#ifndef _GPIO_HANDLER_H_
#define _GPIO_HANDLER_H_



#define PushButton_0     GPIO_PUSH_BUTTON_0
#define PushButton_1    GPIO_PUSH_BUTTON_1
#define PushButton_2		GPIO_PUSH_BUTTON_2

bool	 JoystickLeftFlag, JoystickRightFlag,  JoystickDownFlag, JoystickUpFlag, JoystickPushFlag, PushButtonFlag_0, PushButtonFlag_1, PushButtonFlag_2;


void configure_push_buttons_IT(void);
void configure_joystick_IT(void);

void interrupt_handler(void);
void clear_input_flags(void);

#endif