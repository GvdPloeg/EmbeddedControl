

#ifndef USART_MENU_H_
#define USART_MENU_H_


void usart_menu(void);


extern volatile  int usart_char;
extern volatile  uint8_t usart_flag;


#endif 