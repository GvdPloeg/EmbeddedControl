

#include "stdint.h"
#include "stdbool.h"
#include "sysclk.h"
#include "board.h"
#include "power_clocks_lib.h"
#include "dip204.h"
#include "usart.h"
#include "print_funcs.h"
#include "pm.h"
#include "time.h"
#include "intc.h"
#include "compiler.h"
#include "spi.h"
#include "delay.h"
#include "tc.h"
#include "gpio.h"
#include "usart_menu.h"
#include "interrupt_handler.h"
#include "init_header.h"
#include "gpio_handler.h"
#include "menu.h"
#include "PWM_handler.h"




#if !defined(EXAMPLE_TC) || !defined(EXAMPLE_TC_IRQ)
#  error The TC preprocessor configuration to use in this example is missing.
#endif

void init_gpio_display(void);
void init_usart(void);


// Flag to update the timer value
volatile static bool update_timer = true;


volatile  int usart_char;
volatile  uint8_t usart_flag = 1;
volatile  uint32_t triggerstart[]={0,0,0,0,0}, triggerstop[]={0,0,0,0,0};
//volatile  uint8_t weektrigger[]={0,0,0,0,0};
volatile  uint8_t weektrigger[]={0,127,127,127,127};
	
volatile int  s_update = 0;




static void tc_irq(void){
	tick_ms++;
	tc_read_sr(EXAMPLE_TC, EXAMPLE_TC_CHANNEL);
	//RT_output_handler();
	RTC_handler();
	Trigger_setter();
	//Primer_handler();
}

static void usart_int_handler(void){
	int c;
	usart_read_char(EXAMPLE_USART, &c);
	usart_char = c;
	usart_flag = 1;
}
	
static void tc_init(volatile avr32_tc_t *tc){
	// Options for waveform generation.
	static const tc_waveform_opt_t waveform_opt = {
		// Channel selection.
		.channel  = EXAMPLE_TC_CHANNEL,
		// Software trigger effect on TIOB.
		.bswtrg   = TC_EVT_EFFECT_NOOP,
		// External event effect on TIOB.
		.beevt    = TC_EVT_EFFECT_NOOP,
		// RC compare effect on TIOB.
		.bcpc     = TC_EVT_EFFECT_NOOP,
		// RB compare effect on TIOB.
		.bcpb     = TC_EVT_EFFECT_NOOP,
		// Software trigger effect on TIOA.
		.aswtrg   = TC_EVT_EFFECT_NOOP,
		// External event effect on TIOA.
		.aeevt    = TC_EVT_EFFECT_NOOP,
		// RC compare effect on TIOA.
		.acpc     = TC_EVT_EFFECT_NOOP,
		/*
		 * RA compare effect on TIOA.
		 * (other possibilities are none, set and clear).
		 */
		.acpa     = TC_EVT_EFFECT_NOOP,
		/*
		 * Waveform selection: Up mode with automatic trigger(reset)
		 * on RC compare.
		 */
		.wavsel   = TC_WAVEFORM_SEL_UP_MODE_RC_TRIGGER,
		// External event trigger enable.
		.enetrg   = false,
		// External event selection.
		.eevt     = 0,
		// External event edge selection.
		.eevtedg  = TC_SEL_NO_EDGE,
		// Counter disable when RC compare.
		.cpcdis   = false,
		// Counter clock stopped with RC compare.
		.cpcstop  = false,
		// Burst signal selection.
		.burst    = false,
		// Clock inversion.
		.clki     = false,
		// Internal source clock 3, connected to fPBA / 8.
		.tcclks   = TC_CLOCK_SOURCE_TC3
	};

	// Options for enabling TC interrupts
	static const tc_interrupt_t tc_interrupt = {
		.etrgs = 0,
		.ldrbs = 0,
		.ldras = 0,
		.cpcs  = 1, // Enable interrupt on RC compare alone
		.cpbs  = 0,
		.cpas  = 0,
		.lovrs = 0,
		.covfs = 0
	};
	// Initialize the timer/counter.
	tc_init_waveform(tc, &waveform_opt);
	
	tc_write_rc(tc, EXAMPLE_TC_CHANNEL, 1500);
	// configure the timer interrupt
	tc_configure_interrupts(tc, EXAMPLE_TC_CHANNEL, &tc_interrupt);
	// Start the timer/counter.
	tc_start(tc, EXAMPLE_TC_CHANNEL);
}
	

inline void init_main(){
	
	volatile avr32_tc_t *tc = EXAMPLE_TC;
	/*
	 * The call to sysclk_init() will disable all non-vital
	 * peripheral clocks, except for the peripheral clocks explicitly
	 * enabled in conf_clock.h.
	 */
	sysclk_init();
	sysclk_enable_peripheral_clock(EXAMPLE_TC);
	init_usart();
	/*
	 * Disable all interrupts while configuring the interrupt controller to
	 * avoid potential spurious interrupts and undefined behavior.
	 */
	Disable_global_interrupt();
		/* Intialize the CPU IRQ vector table */

		INTC_init_interrupts();
		INTC_register_interrupt(&tc_irq, EXAMPLE_TC_IRQ, EXAMPLE_TC_IRQ_PRIORITY);				//configure the 1ms interrupt
		INTC_register_interrupt(&usart_int_handler, AVR32_USART1_IRQ, AVR32_INTC_INT0);
		EXAMPLE_USART->ier = AVR32_USART_IER_RXRDY_MASK;
		configure_push_buttons_IT();			// configure local push buttons
		configure_joystick_IT();				// configure local joystick
		
	Enable_global_interrupt();	/* Enable all interrupts */
		PWM_init();
		tc_init(tc);
		init_gpio_display();
		PWM_setter_update();
}




void init_usart(){
	pcl_switch_to_osc(0, FOSC0, OSC0_STARTUP);
	
	static const gpio_map_t USART_GPIO_MAP =
	{
		{AVR32_USART1_RXD_0_0_PIN, AVR32_USART1_RXD_0_0_FUNCTION},
		{AVR32_USART1_TXD_0_0_PIN, AVR32_USART1_TXD_0_0_FUNCTION}
	};

	// USART options.
	static const usart_options_t USART_OPTIONS =
	{
		.baudrate     = 57600,
		.charlength   = 8,
		.paritytype   = USART_NO_PARITY,
		.stopbits     = USART_1_STOPBIT,
		.channelmode  = USART_NORMAL_CHMODE
	};

	// Assign GPIO to USART.
	gpio_enable_module(USART_GPIO_MAP,
			sizeof(USART_GPIO_MAP) / sizeof(USART_GPIO_MAP[0]));

	// Initialize USART in RS232 mode.
	usart_init_rs232((&AVR32_USART1), &USART_OPTIONS, FOSC0);
}


	

void init_gpio_display(){
	
	static const gpio_map_t DIP204_SPI_GPIO_MAP =
	{
	{DIP204_SPI_SCK_PIN,  DIP204_SPI_SCK_FUNCTION },  // SPI Clock.
	{DIP204_SPI_MISO_PIN, DIP204_SPI_MISO_FUNCTION},  // MISO.
	{DIP204_SPI_MOSI_PIN, DIP204_SPI_MOSI_FUNCTION},  // MOSI.
	{DIP204_SPI_NPCS_PIN, DIP204_SPI_NPCS_FUNCTION}   // Chip Select NPCS.
	};
 
	spi_options_t spiOptions =			// add the spi options driver structure for the LCD DIP204
	{
	.reg          = DIP204_SPI_NPCS,
	.baudrate     = 1000000,
	.bits         = 8,
	.spck_delay   = 0,
	.trans_delay  = 0,
	.stay_act     = 1,
	.spi_mode     = 0,
	.modfdis      = 1
	};
	
	gpio_enable_module(DIP204_SPI_GPIO_MAP,					// Assign I/Os to SPI
	sizeof(DIP204_SPI_GPIO_MAP) / sizeof(DIP204_SPI_GPIO_MAP[0]));
	spi_initMaster(DIP204_SPI, &spiOptions);				// Initialize as master
	spi_selectionMode(DIP204_SPI, 0, 0, 0);					// Set selection mode: variable_ps, pcs_decode, delay
	spi_enable(DIP204_SPI);									// Enable SPI
	spi_setupChipReg(DIP204_SPI, &spiOptions, FOSC0);		// setup chip registers
  
    dip204_init(backlight_PWM, true);	
	unsigned short current_char = 0;						// initialize LCD
    current_char = 0x10;									// reset marker
}