

#ifndef _INIT_HEADER_H_
#define _INIT_HEADER_H_


//! \note TC module is used in this example.
#define EXAMPLE_TC                 (&AVR32_TC)
//! \note TC Channel 0 is used.
#define EXAMPLE_TC_CHANNEL         0
//! \note IRQ0 line of channel 0 is used.
#define EXAMPLE_TC_IRQ             AVR32_TC_IRQ0
//! \note IRQ Group of TC module
#define EXAMPLE_TC_IRQ_GROUP       AVR32_TC_IRQ_GROUP
//! \note Interrupt priority 0 is used for TC in this example.
#define EXAMPLE_TC_IRQ_PRIORITY    AVR32_INTC_INT0

#define EXAMPLE_USART                 (&AVR32_USART1)

#define xselector 0
#define xmenu 3
#define xpos0 6
#define EXAMPLE_DELAY_MS        1000
#define ss_const 1000
#define	mm_const ss_const*60
#define	hh_const mm_const*60
#define dd_const hh_const*24



/*! flag set when joystick display starts to signal main function to clear this display */
unsigned short display;

/** Counter to store the number for COMPARE interrupts. */

uint32_t				tick_ms;


/** Number of clock cycles representing the \ref EXAMPLE_DELAY_MS. */
volatile uint32_t        delay_clock_cycles;
/** Flag to indicate that the ISR has fired. */

static volatile bool	 timeselect[]={0,0,0,0,0};
	
volatile extern uint8_t  weektrigger[];
volatile static uint8_t  menu_selector=1;

//volatile static uint32_t triggerstart[]={0,0,0,0,0}, triggerstop[]={0,0,0,0,0};
volatile extern uint32_t triggerstart[], triggerstop[];


uint32_t				 millis;
uint32_t				 pmillis;
uint32_t				 pmillisread;




void init_main(void);


#endif