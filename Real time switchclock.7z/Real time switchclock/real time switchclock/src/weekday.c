/*
 * weekday.c
 *
 * Created: 15-10-2018 11:21:04
 *  Author: Anglclaw
 */ 

#include "weekday.h"
#include "dip204.h"


void print_WeekDay(int _weekday){
	switch(_weekday){
		case (1):
		dip204_printf_string("Monday");
		break;
		case (2):
		dip204_printf_string("Tuesday");
		break;
		case (3):
		dip204_printf_string("Wednesday");
		break;
		case (4):
		dip204_printf_string("Thursday");
		break;
		case (5):
		dip204_printf_string("Friday");
		break;
		case (6):
		dip204_printf_string("Saturday");
		break;
		case (7):
		dip204_printf_string("Sunday");
		break;
	}
}

void print_short_WeekDay(int _weekday){
	switch(_weekday){
		case (1):
		dip204_printf_string("Mon");
		break;
		case (2):
		dip204_printf_string("Tue");
		break;
		case (3):
		dip204_printf_string("Wed");
		break;
		case (4):
		dip204_printf_string("Thu");
		break;
		case (5):
		dip204_printf_string("Fri");
		break;
		case (6):
		dip204_printf_string("Sat");
		break;
		case (7):
		dip204_printf_string("Sun");
		break;
	}
}

void print_ultrashort_WeekDay(int _weekday){
	switch(_weekday){
		case (1):
		dip204_printf_string("M");
		break;
		case (2):
		dip204_printf_string("T");
		break;
		case (3):
		dip204_printf_string("W");
		break;
		case (4):
		dip204_printf_string("T");
		break;
		case (5):
		dip204_printf_string("F");
		break;
		case (6):
		dip204_printf_string("S");
		break;
		case (7):
		dip204_printf_string("S");
		break;
	}
}

int weekday_roll_over(_weekday){
	if (_weekday==0){
		return 7;
	}
	if (_weekday==8){
		return 1;
	}
	if (_weekday==9){
		return 2;
	}
}