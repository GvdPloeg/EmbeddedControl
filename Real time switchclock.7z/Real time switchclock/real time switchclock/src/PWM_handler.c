

#include "pwm.h"
#include "gpio.h"
#include "board.h"

//debug include 
//#include "print_funcs.h"



void PWM_update(int, int, int);
void PWM_init();

void PWM_init(){
	pwm_opt_t pwm_opt;    
	gpio_enable_module_pin(AVR32_PWM_0_PIN, AVR32_PWM_0_FUNCTION);
	gpio_enable_module_pin(AVR32_PWM_1_PIN, AVR32_PWM_1_FUNCTION);
	gpio_enable_module_pin(AVR32_PWM_2_PIN, AVR32_PWM_2_FUNCTION);
	gpio_enable_module_pin(AVR32_PWM_3_PIN, AVR32_PWM_3_FUNCTION);
	
	pwm_opt.diva = AVR32_PWM_DIVA_CLK_OFF;
	pwm_opt.divb = AVR32_PWM_DIVB_CLK_OFF;
	pwm_opt.prea = AVR32_PWM_PREA_MCK;
	pwm_opt.preb = AVR32_PWM_PREB_MCK;
	pwm_init(&pwm_opt);
}


void PWM_update(int channel_id, int freq, int DuCy){
	pwm_opt_t pwm_opt;                                // PWM option config.
	avr32_pwm_channel_t pwm_channel = { .ccnt = channel_id };  // One channel config.
	  
	// The channel number and instance is used in several functions.
	// It's defined as local variable for ease-of-use.

	uint32_t t_prd = 12000000/freq;									//convert frequency to period length
	  
	pwm_opt.diva = AVR32_PWM_DIVA_CLK_OFF;
	pwm_opt.divb = AVR32_PWM_DIVB_CLK_OFF;
	pwm_opt.prea = AVR32_PWM_PREA_MCK;
	pwm_opt.preb = AVR32_PWM_PREB_MCK;

	pwm_init(&pwm_opt);

	pwm_channel.CMR.calg = PWM_MODE_LEFT_ALIGNED;					// Channel mode.
	pwm_channel.CMR.cpol = PWM_POLARITY_HIGH;						// Channel polarity.
	pwm_channel.CMR.cpd = PWM_UPDATE_DUTY;							// Not used the first time.
	int z = 0;
	for (z = 0; t_prd > 65536; z++){								//this loop ensures that accurate prescalar setting can be achieved
		t_prd = t_prd/2;
	}  
	uint32_t t_on = (t_prd*DuCy)/100;
  	switch (z){														//set prescalar in accordance to times loop has been cycled
	  	case(0):
	  	pwm_channel.CMR.cpre = 0;
	  	break;
	  	case(1):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_2;
	  	break;
	  	case(2):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_4;
	  	break;
	  	case(3):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_8;
	  	break;
	  	case(4):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_16;
	  	break;
	  	case(5):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_32;
	  	break;
	  	case(6):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_64;
	  	break;
	  	case(7):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_128;
	  	break;
	  	case(8):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_256;
	  	break;
	  	case(9):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_512;
	  	break;
	  	case(10):
	  	pwm_channel.CMR.cpre = AVR32_PWM_CMR0_CPRE_MCK_DIV_1024;
	  	break;
  	}
	pwm_channel.cdty = t_on;   // Channel duty cycle, should be < CPRD.
	pwm_channel.cprd = t_prd;  // Channel period.
	pwm_channel.cupd = 0;   // Channel update is not used here.
	
	pwm_channel_init(channel_id, &pwm_channel); // Set channel configuration to channel 0.
}
