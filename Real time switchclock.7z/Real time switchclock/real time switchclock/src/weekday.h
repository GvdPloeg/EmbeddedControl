/*
 * weekday.h
 *
 * Created: 15-10-2018 11:19:47
 *  Author: Anglclaw
 */ 


#ifndef WEEKDAY_H_
#define WEEKDAY_H_

void print_WeekDay(int _weekday);
void print_short_WeekDay(int _weekday);
void print_ultrashort_WeekDay(int _weekday);
int weekday_roll_over(int _weekday);

#endif /* WEEKDAY_H_ */