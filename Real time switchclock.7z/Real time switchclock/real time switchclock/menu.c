

#include "stdint.h"
#include "compiler.h"
#include "board.h"
#include "dip204.h"
#include "gpio.h"
#include "time.h"
#include "interrupt_handler.h"
#include "usart.h"
#include "init_header.h"
#include "gpio_handler.h"
#include "weekday.h"
#include "print_funcs.h"
#include "usart_menu.h"
#include "PWM_handler.h"
#include "pwm.h"


#define init_time_display 0
#define time_display 1
#define init_selection_menu 2
#define selection_menu 3
#define init_timeset_menu 4
#define timeset_menu 5
#define timeset_menu_e 6
#define weekday_menu 7
#define init_PWM_menu 8
#define PWM_menu 9
#define init_current_timeset_menu 10
#define current_timeset_menu 11


void menuloop(void);

void f_init_time(void);
void f_time_display(void);
void f_init_selection_menu(void);
void f_time(void);
void clearclutter(char, char);
void printmenu(char, char, char);
void f_selection_menu(void);
void f_init_timeset_menu(void);
void f_timeset_menu(void);
void SetBeginTime(int);
void SetEndTime(int);
void f_weekday_menu(void);
void f_PWM_menu(void);
void print_weekDay_menu(int ,int ,int ,int);
void print_weekday_menu(int);
void Set_PWM_freq(int);									
void Set_PWM_DuCy(int);
void Set_PWM_freq_MF(int);
void Set_PWM_DuCy_MF(int);
void Set_PWM_mode(void);
void Set_PWM_Select(void);
void f_init_PWM_menu(int);
void PWM_HF_values(void);
void f_init_current_timeset_menu(void);
void f_current_timeset_menu(void);
void SetCurrentTime(int);

void print_day(int, int);
void set_weekday_trigger(int);
void split_triggers(int);
void PWM_setter_update(void);
void Trigger_primer(void);
void PWM_push_values(void);

void debug_mode(void);


int x=0, y=1, select=0, a=0, xprev=0;
int state=0;
int i=0;

	
volatile uint32_t hhstart[]={0,0,0,0,0}, mmstart[]={0,0,0,0,0}, ssstart[]={0,0,0,0,0}, millisstart[]={0,0,0,0,0};
volatile uint32_t Current_hh = 0, Current_mm = 0, Current_ss = 0, Current_millis = 0;
volatile uint8_t  Current_weekday;
volatile static uint32_t hhstop[]={0,0,0,0,0}, mmstop[]={0,0,0,0,0}, ssstop[]={0,0,0,0,0}, millisstop[]={0,0,0,0,0};
volatile uint16_t PWM_frequency[]={0,1,1,1,1}, PWM_DutyCycle[]={0,50,50,50,50};
volatile uint32_t PWM_modifier[]={0,1000,1000,1000,1000};
volatile uint16_t PWM_DuCy_buff;
volatile uint16_t PWM_frequency_buff = 0;
volatile uint32_t PWM_modifier_buff = 0;
	
static int PWM_select = 0;
volatile static int 	PWM_HF_frequency_state_pointer[] = {0,0,0,0,0};
volatile static int		PWM_modeselect[] = {0,1,1,1,1};
static int debugflag = 0;
static volatile  int trigger[];
static volatile uint32_t primer_1[];
static volatile uint32_t primer_0[];

uint8_t	tick_day = 1;


bool init_week_clear;





void menuloop(void)
{
	dip204_hide_cursor();
	while(1){
		Trigger_primer();												//primes triggers 1ms before they should resolve, triggers will resolve in next tc_irq
		//PWM_setter_update();
		usart_menu();
		switch(state){
			case (init_time_display):
				clear_input_flags();
				f_init_time();
				state=time_display;
				break;
			case (time_display):
				f_time_display();
				break;
			case (init_selection_menu):									//initialize selection menu
				f_init_selection_menu();
				break;
			case (selection_menu):										//selection menu
				f_selection_menu();
				break;
			case (init_timeset_menu):									//initialize timesetting menu
				f_init_timeset_menu();
				break;
			case (timeset_menu):										//timesetting menu
				f_timeset_menu();
				break;
			case (init_current_timeset_menu):									
				f_init_current_timeset_menu();
				break;
			case (current_timeset_menu):										
				f_current_timeset_menu();
				break;
			case (weekday_menu):
				f_weekday_menu();
				break;
			case (init_PWM_menu):
				f_init_PWM_menu(1);
				break;
			case (PWM_menu):
				f_PWM_menu();
				break;
		}
		if(state==timeset_menu_e){
			state=timeset_menu;
		}
	}
}

void f_init_time(){																//print initial parts of time display menu
	dip204_clear_display();
	if (debugflag == 8){
		dip204_set_cursor_position(xpos0,1);
		dip204_printf_string("Debug Mode");
	}
	dip204_set_cursor_position(xpos0+8,2);
	dip204_printf_string(":%02d", millis);										//milliseconds are printed seperately
	dip204_set_cursor_position(xpos0-4,2);
	print_short_WeekDay(tick_day);
	dip204_set_cursor_position(xpos0,2);
	const time_t tsbuffer = tick_ms/1000;										//time is printed using the time.h library
	struct tm *tmp = gmtime(&tsbuffer);											
	dip204_printf_string("%02d:%02d:%02d", tmp->tm_hour,tmp->tm_min,tmp->tm_sec);
	clearclutter(xpos0+11,2);
}

void f_time_display(){															//continious time display
	dip204_set_cursor_position(xpos0+8,2);
	dip204_printf_string(":%02d", millis);										//prints milliseconds as fast as possible
	if (s_update == 1){															//only update the rest of the screen every second
		dip204_set_cursor_position(xpos0-4,2);
		print_short_WeekDay(tick_day);
		dip204_set_cursor_position(xpos0,2);
		const time_t tsbuffer = tick_ms/1000;
		struct tm *tmp = gmtime(&tsbuffer);
		dip204_printf_string("%02d:%02d:%02d", tmp->tm_hour,tmp->tm_min,tmp->tm_sec);
		s_update = 0;
	}
	if(PushButtonFlag_2 == 1){													//PB2 enters selection menu
		state = init_selection_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_0 == 1){													//PB0 enters current time setting menu
		state = init_current_timeset_menu;
		clear_input_flags();
	}
	debug_mode();		//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT
						//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT
						//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT//REMOVE BEFORE RELEASING PRODUCT
}

void clearclutter (char x, char y){
	dip204_set_cursor_position(x,y);
	dip204_printf_string(" ");
}

void printmenu (char x, char y, char opcode){						//function that prints parts of the menu based on opcode and location coordinates ****Note: clunky and hard to read****
	if (opcode==0){													
		dip204_set_cursor_position(x,y);
		dip204_printf_string("*");
	}
	if (opcode==1){
		dip204_set_cursor_position(x,y);
		dip204_printf_string(">");
	}
	if (opcode==2){
		dip204_set_cursor_position(x,y);
		dip204_printf_string("<");
	}
	if (opcode==3){
		dip204_set_cursor_position(1,2);
		dip204_printf_string("Bgn");
		dip204_set_cursor_position(1,3);
		dip204_printf_string("End");
		dip204_set_cursor_position(6,4);
		dip204_printf_string("hh:mm:ss:mil");
		dip204_set_cursor_position(xpos0+12,2);
		dip204_printf_string("<");
		dip204_set_cursor_position(xpos0-1,2);
		dip204_printf_string(">");
	}
	if (opcode==4){
		dip204_set_cursor_position(x,y);
		if (PWM_modifier_buff == 1000000)
			dip204_printf_string("MHz");
		if (PWM_modifier_buff == 1000)
			dip204_printf_string("kHz");
		if (PWM_modifier_buff == 1)
			dip204_printf_string("Hz ");
	}
}

void f_init_selection_menu(){												//prints the static parts of the selection menu, menu_selector determines which menu should be printed
	int x, y;
	dip204_clear_display();
	x=xmenu;
	for (y=1;y!=5;y++){
		split_triggers(y);
		dip204_set_cursor_position(x,y);	// Display timerselect menu
		if (menu_selector==0){												//print endtimes 
			dip204_printf_string("T%d %02d:%02d:%02d:%03d", y, hhstop[y],mmstop[y],ssstop[y],millisstop[y]);
		}
		if (menu_selector==1){												//print begintimes
			dip204_printf_string("T%d %02d:%02d:%02d:%03d", y, hhstart[y],mmstart[y],ssstart[y],millisstart[y]);
		}
		if (menu_selector==2){												//print days on which timers are active 
			dip204_printf_string("T%d ", y);
			int weekday;
			for ( weekday = 1; weekday <= 7; weekday++ ){
				if (((weektrigger[y] >> (weekday-1)) & 1) == 1){
					print_ultrashort_WeekDay(weekday);						//print single letter of weekday to indicate it being active, followed by a space
					dip204_printf_string(" ");
				}
				else{
					dip204_printf_string("  ");								//print 2 spaces to indicate that day being inactive
				}
			}
		}
		if (menu_selector==3){
			dip204_set_cursor_position(x,y);	
			dip204_printf_string("T%d %3d", y, PWM_frequency[y]);
			if (PWM_modifier[y] == 1000000)
				dip204_printf_string("MHz");
			if (PWM_modifier[y] == 1000)
				dip204_printf_string("kHz ");
			if (PWM_modifier[y] == 1)
				dip204_printf_string("Hz  ");
			dip204_set_cursor_position(xpos0+7,y);	
			dip204_printf_string("%3d", PWM_DutyCycle[y]);
			dip204_write_data(0x25);
		}
		if (timeselect[y]==1){
			printmenu(xpos0,y,0);
		}
	}
	if (menu_selector==1){							//print BGN vertical
		dip204_set_cursor_position(20,1);
		dip204_printf_string("B");
		dip204_set_cursor_position(20,2);
		dip204_printf_string("G");
		dip204_set_cursor_position(20,3);
		dip204_printf_string("N");
	}
	if (menu_selector==0){							//print END vertical 
		dip204_set_cursor_position(20,1);
		dip204_printf_string("E");
		dip204_set_cursor_position(20,2);
		dip204_printf_string("N");
		dip204_set_cursor_position(20,3);
		dip204_printf_string("D");
	}
	if (menu_selector==2){							//print WEEK vertical
		dip204_set_cursor_position(20,1);
		dip204_printf_string("W");
		dip204_set_cursor_position(20,2);
		dip204_printf_string("E");
		dip204_set_cursor_position(20,3);
		dip204_printf_string("E");
		dip204_set_cursor_position(20,4);
		dip204_printf_string("K");
	}
	if (menu_selector==3){							//print PWM vertical
		dip204_set_cursor_position(20,1);
		dip204_printf_string("P");
		dip204_set_cursor_position(20,2);
		dip204_printf_string("W");
		dip204_set_cursor_position(20,3);
		dip204_printf_string("M");
	}
	y=1;
	state = selection_menu;
}

void f_selection_menu(){
	x=1;
	printmenu(xpos0-4,y,0);
	debug_mode();
//	dip204_set_cursor_position(x,y);
	if((JoystickUpFlag == 1)&&(y!=1)){                                                      //scroll up through timers
		clearclutter(xpos0 - 4, y); 
		y--;
		clear_input_flags();
	}
	if((JoystickDownFlag == 1)&&(y!=4)){                                                    //scroll down through timers
		clearclutter(xpos0 - 4, y); 
		y++;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1 && (menu_selector == 0)){										//pressing PB2 enters timeset menu for setting stop times when viewing stop times
		i = y;
		state = init_timeset_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1 && (menu_selector == 1)){										//pressing PB2 enters timeset menu for setting start times when viewing start times
		i = y;
		state = init_timeset_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1 && (menu_selector == 3)){										//pressing PB2 enters PWM setting menu when viewing PWM selection menu
		i = y;
		state = init_PWM_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1 && (menu_selector == 2)){										//pressing PB2 enters weekday setting menu when viewing weekday selection menu
		i = y;
		dip204_clear_display();
		state = weekday_menu;
		clear_input_flags();
	}
	if(PushButtonFlag_1 == 1){																//PB1 to exit to time display/default screen
		state = init_time_display;
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&(menu_selector==0)){										//cycle through selection menu's using PB0
		menu_selector = 2;
		state = init_selection_menu;
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&(menu_selector==1)){										//cycle through selection menu's using PB0
		menu_selector = 0;
		state = init_selection_menu;
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&(menu_selector==2)){										//cycle through selection menu's using PB0
		menu_selector = 3;
		state = init_selection_menu;
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&(menu_selector==3)){										//cycle through selection menu's using PB0
		menu_selector = 1;
		state = init_selection_menu;
		clear_input_flags();
	}
}

void f_init_timeset_menu(){						//prints static components of timeset menu
	dip204_clear_display();
	x=xpos0;
	xprev=0;
	state = timeset_menu;
	menu_selector = 1;
	dip204_set_cursor_position(1,1);
	dip204_printf_string("T%d", i);				//print timer ID
	printmenu(0,0,3);							//prints static menu parts
	if (timeselect[i]==1){
		printmenu(xpos0+15,2,0);
	}
	if (timeselect[i]==0){
		printmenu(xpos0+15,3,0);
	}
}

void f_timeset_menu(){
	dip204_set_cursor_position(xpos0,2);
	dip204_printf_string("%02d:%02d:%02d:%03d", hhstart[i],mmstart[i],ssstart[i],millisstart[i]);   //Display timesetting menu start time
	dip204_set_cursor_position(xpos0,3);
	dip204_printf_string("%02d:%02d:%02d:%03d", hhstop[i],mmstop[i],ssstop[i],millisstop[i]);		//Display timesetting menu stop time
	if((JoystickLeftFlag == 1) &&(x!=xpos0)){					//cursor scroll left using joystick
		x--;
		if(x==xpos0+2)x--;                                      //skip unselectable parts
		if(x==xpos0+5)x--;                                      //skip unselectable parts
		if(x==xpos0+8)x--;
		clear_input_flags();
	}
	if((JoystickRightFlag == 1) &&(x!=xpos0+11)){				//cursor scroll right using joystick
		x++;
		if(x==xpos0+2)x++;                                      //skip unselectable parts
		if(x==xpos0+5)x++;                                      //skip unselectable parts
		if(x==xpos0+8)x++;
		clear_input_flags();
	}
	
	if(PushButtonFlag_1 == 1){									//go back to previous menu using PB1
		state = init_selection_menu;
		clear_input_flags();
	}
	
	if((PushButtonFlag_0 == 1)&&menu_selector==1){				//select start or stop timers using PB0
		menu_selector=0;
		clearclutter(xpos0-1,2);
		printmenu(xpos0-1,3,1);
		clearclutter(xpos0+12,2);
		printmenu(xpos0+12,3,2);
		clear_input_flags();
	}
	if((PushButtonFlag_0 == 1)&&menu_selector==0){				//select start or stop timers using PB0
		menu_selector=1;
		clearclutter(xpos0-1,3);
		printmenu(xpos0-1,2,1);
		clearclutter(xpos0+12,3);
		printmenu(xpos0+12,2,2);
		clear_input_flags();
	}
	if (xprev!=x){												//erase prev cursor and print new
		clearclutter(xprev,1);
		printmenu(x,1,0);
		xprev=x;
	}
	//if (PushButtonFlag_2 == 1){									//press PB2 to enter the weekday setting menu from the timesetting menu
		//state = weekday_menu;
		//init_week_clear = 1;
		//clear_input_flags();
	//}
	if(JoystickUpFlag == 1){
		if (menu_selector == 1){
			SetBeginTime(1);									// 1 = opcode up, 0 = opcode down
		}
		if (menu_selector == 0){
			SetEndTime(1);										// 1 = opcode up, 0 = opcode down
		}
		clear_input_flags();
	}
	if (JoystickDownFlag == 1){
		if (menu_selector == 1){
			SetBeginTime(0);									// 1 = opcode up, 0 = opcode down
		}
		if (menu_selector == 0){
			SetEndTime(0);										// 1 = opcode up, 0 = opcode down
		}
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1){									//PB1 to exit menu and save new settings
		triggerstart[i]	= hhstart[i]*hh_const+mmstart[i]*mm_const+ssstart[i]*ss_const+millisstart[i];
		triggerstop[i]	= hhstop[i]*hh_const+mmstop[i]*mm_const+ssstop[i]*ss_const+millisstop[i];
		state = init_selection_menu;
		clear_input_flags();
	}
}


void f_init_current_timeset_menu(){								//print static parts of the current timesetting menu
	split_triggers(0);	
	Current_weekday = tick_day;
	dip204_clear_display();
	dip204_set_cursor_position(xpos0-4,2);
	print_short_WeekDay(tick_day);
	x=xpos0;
	xprev=0;
	state = current_timeset_menu;
	menu_selector = 1;
	dip204_set_cursor_position(5,3);
//	printmenu(0,0,3);											//prints static menu parts
}


void f_current_timeset_menu(){
	dip204_set_cursor_position(xpos0,2);
	dip204_printf_string("%02d:%02d:%02d:%03d", Current_hh,Current_mm,Current_ss,Current_millis);    //Display timesetting menu start time
	//scroll left using joystick
	if((JoystickLeftFlag == 1) &&(x!=xpos0-4)){                 //cursor scroll left
		x--;
		if(x==xpos0-1)x = xpos0 - 4;
		if(x==xpos0+2)x--;                                      //skip unselectable parts
		if(x==xpos0+5)x--;                                      //skip unselectable parts
		if(x==xpos0+8)x--;										//skip unselectable parts
		clear_input_flags();
	}
	//scroll right using joystick
	if((JoystickRightFlag == 1) &&(x!=xpos0+11)){               //cursor scroll right
		x++;
		if(x==xpos0-4)x = xpos0;
		if(x==xpos0+2)x++;                                      //skip unselectable parts
		if(x==xpos0+5)x++;                                      //skip unselectable parts
		if(x==xpos0+8)x++;										//skip unselectable parts
		clear_input_flags();
	}
	if (xprev!=x){												//erase prev cursor and print new
		clearclutter(xprev,1);
		printmenu(x,1,0);
		xprev=x;
	}
	if(JoystickUpFlag == 1){
		SetCurrentTime(1);										// 1 = opcode up, 0 = opcode down
		clear_input_flags();
	}
	if (JoystickDownFlag == 1){
		SetCurrentTime(0);										// 1 = opcode up, 0 = opcode down
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1){									//PB2 to push new settings to current time
		tick_ms	= Current_hh*hh_const+Current_mm*mm_const+Current_ss*ss_const+Current_millis;
		tick_day = Current_weekday;
		pmillis = tick_ms;
		millis = Current_millis;
		state = init_time_display;
		clear_input_flags();
	}
	if(PushButtonFlag_1 == 1){									//PB1 to exit menu without saving
		state = init_time_display;
		clear_input_flags();
	}
}

void SetCurrentTime(int opcode){								//this menu changes the current time and day
	if (opcode==1){
		if (x==xpos0 - 4){										//day + 1
			Current_weekday++;
			Current_weekday = weekday_roll_over(Current_weekday);
			dip204_set_cursor_position(xpos0-4,2);
			print_short_WeekDay(Current_weekday);
		}
		if(x==xpos0&&Current_hh<=13){							//hours +10
			Current_hh=Current_hh+10;
		}
		if(x==xpos0+1&&Current_hh<23){							//hours +1
			Current_hh++;
		}
		//minutes
		if(x==xpos0+3&&Current_mm<=49){							//minutes +10
			Current_mm=Current_mm+10;
		}
		if(x==xpos0+4&&Current_mm<59){							//minutes +1
			Current_mm++;
		}
		//seconds
		if(x==xpos0+6&&Current_ss<=49){							//seconds +10
			Current_ss=Current_ss+10;
		}
		if(x==xpos0+7&&Current_ss<59){							//seconds +1
			Current_ss++;
		}
		//milliseconds
		if(x==xpos0+9&&Current_millis<=899){					//milliseconds +100
			Current_millis=Current_millis+100;
		}
		if(x==xpos0+10&&Current_millis<=989){					//milliseconds +10
			Current_millis=Current_millis+10;
		}
		if(x==xpos0+11&&Current_millis<999){					//milliseconds +1
			Current_millis++;
		}
	}
	if (opcode==0){												//day - 1
		if (x==xpos0-4){
			Current_weekday--;
			Current_weekday = weekday_roll_over(Current_weekday);
			dip204_set_cursor_position(xpos0-4,2);
			print_short_WeekDay(Current_weekday);
		}
		if(x==xpos0&&Current_hh>=10){							//hours -10
			Current_hh=Current_hh-10;
		}
		if(x==xpos0+1&&Current_hh>=1){                          //hours -1
			Current_hh--;
		}
		//minutes
		if(x==xpos0+3&&Current_mm>=10){							//minutes -10
			Current_mm=Current_mm-10;
		}
		if(x==xpos0+4&&Current_mm>=1){                          //minutes -1
			Current_mm--;
		}
		//seconds
		if(x==xpos0+6&&Current_ss>=10){							//seconds -10
			Current_ss=Current_ss-10;
		}
		if(x==xpos0+7&&Current_ss>=1){                          //seconds -1
			Current_ss--;
		}
		//milliseconds
		if(x==xpos0+9&&Current_millis>=100){					//milliseconds -100
			Current_millis=Current_millis-100;
		}
		if(x==xpos0+10&&Current_millis>=10){					//milliseconds -10
			Current_millis=Current_millis-10;
		}
		if(x==xpos0+11&&Current_millis>=1){						//milliseconds -1
			Current_millis--;
		}
	}
}


void SetBeginTime(int opcode){
	if (opcode==1){												//opcode 1 for up
		if(x==xpos0&&hhstart[i]<=13){							//hours +10
			hhstart[i]=hhstart[i]+10;
		}
		if(x==xpos0+1&&hhstart[i]<23){							//hours +1
			hhstart[i]++;
		}
		//minutes
		if(x==xpos0+3&&mmstart[i]<=49){							//minutes +10
			mmstart[i]=mmstart[i]+10;
		}
		if(x==xpos0+4&&mmstart[i]<59){							//minutes +1
			mmstart[i]++;
		}
		//seconds
		if(x==xpos0+6&&ssstart[i]<=49){							//seconds +10
			ssstart[i]=ssstart[i]+10;
		}
		if(x==xpos0+7&&ssstart[i]<59){							//seconds +1
			ssstart[i]++;
		}
		//milliseconds
		if(x==xpos0+9&&millisstart[i]<=899){					//milliseconds +100
			millisstart[i]=millisstart[i]+100;
		}
		if(x==xpos0+10&&millisstart[i]<=989){					//milliseconds +10
			millisstart[i]=millisstart[i]+10;
		}
		if(x==xpos0+11&&millisstart[i]<999){					//milliseconds +1
			millisstart[i]++;
		}
	}
	if (opcode==0){												//opcode 0 for down
		if(x==xpos0&&hhstart[i]>=10){							//hours -10
			hhstart[i]=hhstart[i]-10;
		}
		if(x==xpos0+1&&hhstart[i]>=1){                          //hours -1
			hhstart[i]--;
		}
		//minutes
		if(x==xpos0+3&&mmstart[i]>=10){							//minutes -10
			mmstart[i]=mmstart[i]-10;
		}
		if(x==xpos0+4&&mmstart[i]>=1){                          //minutes -1
			mmstart[i]--;
		}
		//seconds
		if(x==xpos0+6&&ssstart[i]>=10){							//seconds -10
			ssstart[i]=ssstart[i]-10;
		}
		if(x==xpos0+7&&ssstart[i]>=1){                          //seconds -1
			ssstart[i]--;
		}
		//milliseconds
		if(x==xpos0+9&&millisstart[i]>=100){					//milliseconds -100
			millisstart[i]=millisstart[i]-100;
		}
		if(x==xpos0+10&&millisstart[i]>=10){					//milliseconds -10
			millisstart[i]=millisstart[i]-10;
		}
		if(x==xpos0+11&&millisstart[i]>=1){						//milliseconds -1
			millisstart[i]--;
		}
	}
}

void SetEndTime(int opcode){
	if (opcode==1){
		if(x==xpos0&&hhstop[i]<=13){							//hours +10
			hhstop[i]=hhstop[i]+10;
		}
		if(x==xpos0+1&&hhstop[i]<23){							//hours +1
			hhstop[i]++;
		}
		//minutes
		if(x==xpos0+3&&mmstop[i]<=49){							//minutes +10
			mmstop[i]=mmstop[i]+10;
		}
		if(x==xpos0+4&&mmstop[i]<59){							//minutes +1
			mmstop[i]++;
		}
		//seconds
		if(x==xpos0+6&&ssstop[i]<=49){							//seconds +10
			ssstop[i]=ssstop[i]+10;
		}
		if(x==xpos0+7&&ssstop[i]<59){							//seconds +1
			ssstop[i]++;
		}
		//milliseconds
		if(x==xpos0+9&&millisstop[i]<=899){						//milliseconds +100
			millisstop[i]=millisstop[i]+100;
		}
		if(x==xpos0+10&&millisstop[i]<=989){					//milliseconds +10
			millisstop[i]=millisstop[i]+10;
		}
		if(x==xpos0+11&&millisstop[i]<999){						//milliseconds +1
			millisstop[i]++;
		}
	}
	if (opcode==0){
		if(x==xpos0&&hhstop[i]>=10){							//hours -10
			hhstop[i]=hhstop[i]-10;
		}
		if(x==xpos0+1&&hhstop[i]>=1){                           //hours -1
			hhstop[i]--;
		}
		//minutes
		if(x==xpos0+3&&mmstop[i]>=10){							//minutes -10
			mmstop[i]=mmstop[i]-10;
		}
		if(x==xpos0+4&&mmstop[i]>=1){                           //minutes -1
			mmstop[i]--;
		}
		//seconds
		if(x==xpos0+6&&ssstop[i]>=10){							//seconds -10
			ssstop[i]=ssstop[i]-10;
		}
		if(x==xpos0+7&&ssstop[i]>=1){                           //seconds -1
			ssstop[i]--;
		}
		//milliseconds
		if(x==xpos0+9&&millisstop[i]>=100){						//milliseconds -100
			millisstop[i]=millisstop[i]-100;
		}
		if(x==xpos0+10&&millisstop[i]>=10){						//seconds -10
			millisstop[i]=millisstop[i]-10;
		}
		if(x==xpos0+11&&millisstop[i]>=1){                      //seconds -1
			millisstop[i]--;
		}
	}
}

void f_weekday_menu(){
	//this function contains the control scheme for the weekday menu
	if (init_week_clear == 1){									//clear display only when changes occur
		dip204_clear_display();
		init_week_clear = 0;
	}
	static int weekday = 1;
	if(JoystickDownFlag == 1){									//scroll down through weekday menu
		weekday++;
		weekday = weekday_roll_over(weekday);
		clear_input_flags();
		init_week_clear = 1;									//reset clearscreen flag after change
	}
	if(JoystickUpFlag == 1){									//scroll up through weekday menu
		weekday--;
		weekday = weekday_roll_over(weekday);
		clear_input_flags();
		init_week_clear = 1;									//reset clearscreen flag after change
	}
	if(PushButtonFlag_2 == 1){
		clear_input_flags();
		set_weekday_trigger(weekday);
	}
	if((PushButtonFlag_1 == 1) && (menu_selector != 2)){
		clear_input_flags();
		state = init_timeset_menu;
	}
	if((PushButtonFlag_1 == 1) && (menu_selector == 2)){
		clear_input_flags();
		state = init_selection_menu;
	}
	print_weekday_menu(weekday);
}


void print_weekday_menu(int weekday){		
	//this function prints the weekday menu
	//in addition to the currently selected day on row 2 it will print the day before on row 1 and 2 days after on row 3 and 4					
	int ypos = 2;
	dip204_set_cursor_position(3,ypos);
	dip204_printf_string(">");
	dip204_set_cursor_position(13,ypos);
	dip204_printf_string("<");
	dip204_set_cursor_position(4,ypos);
	print_day(weekday, ypos);
	ypos = 1;
	dip204_set_cursor_position(4,ypos);
	print_day((weekday-1), ypos);
	ypos = 3;
	dip204_set_cursor_position(4,ypos);
	print_day((weekday+1), ypos);
	ypos = 4;
	dip204_set_cursor_position(4,ypos);
	print_day((weekday+2), ypos);
}

void print_day(int wbuffer, int ypos){
	wbuffer = weekday_roll_over(wbuffer);
	print_WeekDay(wbuffer);
	if (((weektrigger[i] >> (wbuffer-1)) & 1) == 1){
		dip204_set_cursor_position(2,ypos);
		dip204_printf_string("*");
	}
	else {
		dip204_set_cursor_position(2,ypos);
		dip204_printf_string(" ");
	}
}

void set_weekday_trigger(int weekday){		
	//The weekday trigger dictates on which days of the week the timer should be active
	//each day of the week is assigned its own bit in a bitmasked array 					
	if (((weektrigger[i] >> (weekday-1)) & 1) == 0){
		weektrigger[i] = weektrigger[i] + (1 << (weekday-1));	
	}
	else{
		weektrigger[i] = weektrigger[i] - (1 << (weekday-1));
	}
}

void split_triggers(int y){		
	//splits the trigger values so that they can be displayed seperately									
	hhstart[y] = (triggerstart[y]/3600000);
	mmstart[y] = (triggerstart[y]-3600000*hhstart[y])/60000;
	ssstart[y] = (triggerstart[y]-3600000*hhstart[y]-mmstart[y]*60000)/1000;
	millisstart[y] = (triggerstart[y]-3600000*hhstart[y]-mmstart[y]*60000-ssstart[y]*1000);
	hhstop[y] = (triggerstop[y]/3600000);
	mmstop[y] = (triggerstop[y]-3600000*hhstop[y])/60000;
	ssstop[y] = (triggerstop[y]-3600000*hhstop[y]-mmstop[y]*60000)/1000;
	millisstop[y] = (triggerstop[y]-3600000*hhstop[y]-mmstop[y]*60000-ssstop[y]*1000);
	Current_hh = (tick_ms/3600000);
	Current_mm = (tick_ms-3600000*Current_hh)/60000;
	Current_ss = (tick_ms-3600000*Current_hh-Current_mm*60000)/1000;
	Current_millis = (tick_ms-3600000*Current_hh-Current_mm*60000-Current_ss*1000);
}

void Trigger_primer(){																	//primes triggers 1ms before they should fire
	int tick_buff = tick_ms+1;															
	for (int k=1;k!=5;k++){
		if (((weektrigger[k] >> (tick_day-1)) & 1) == 1){								//only attempt to calculate trigger times when trigger should be active on this day
			if(triggerstart[k]<triggerstop[k]){											//comparisons for when the channel should not be active at hour 0
				if((triggerstart[k]<tick_buff)&&(tick_buff<triggerstop[k])){
					//primer_1[k] = triggerstart[k] - tick_ms;
					trigger[k] = 1;
				}
				if((triggerstart[k]>tick_buff)||(tick_buff>triggerstop[k])){
					//primer_0[k] = triggerstop[k] - tick_ms;
					trigger[k] = 0;
				}
			}
			if(triggerstart[k]>triggerstop[k]){											//comparisons for when the channel should be active at hour 0
				if((triggerstart[k]<tick_buff)||(tick_buff<triggerstop[k])){
					trigger[k] = 1;
					//primer_1[k] = triggerstart[k] - tick_ms;
				}
				if((triggerstart[k]>tick_buff)&&(tick_buff>triggerstop[k])){
					trigger[k] = 0;
					//primer_0[k] = triggerstop[k] - tick_ms;
				}
			}
		}
		if (((weektrigger[k] >> (tick_day-1)) & 1) == 0){								//make trigger 0 when it should not be active on this day of the week
			trigger[k] = 0;
		}
	}
}




void f_init_PWM_menu(int _init){
	dip204_clear_display();
	dip204_set_cursor_position(1,1);
	dip204_printf_string("T%d", i);								//print timer ID
	dip204_set_cursor_position(4,1);
	if (_init == 1){
		PWM_frequency_buff = PWM_frequency[i];
		PWM_DuCy_buff = PWM_DutyCycle[i];
		PWM_modifier_buff = PWM_modifier[i];
		_init = 0;
	}
	switch (PWM_modeselect[i]){									//print different title respresenting the mode of the PWM channel 
		case(0):
		PWM_modifier_buff = 1;
		dip204_printf_string("LF Mode");						
		break;
		case(1):
		PWM_modifier_buff = 1000;
		dip204_printf_string("MF Mode");
		break;
		case(2):
		dip204_printf_string("HF Mode");
		break;		
	}
	if (PWM_select == 0){										//print a cursor in front of the frequency selector to represent frequency selection being the current mode
		clearclutter(xpos0-4,3);
		dip204_set_cursor_position(xpos0-4,2);
		dip204_printf_string("*");
	}
	else {														//print a cursor in front of the duty cycle selector to represent duty cycle selection being the current mode
		clearclutter(xpos0-4,2);
		dip204_set_cursor_position(xpos0-4,3);
		dip204_printf_string("*");
	}
	dip204_set_cursor_position(xpos0-3,2);
	dip204_printf_string("Frequency: %03d", PWM_frequency_buff);
	printmenu(17,2,4);											//print Hz, kHz or MHz 
	dip204_set_cursor_position(xpos0-3,3);
	dip204_printf_string("DutyCycle: %03d", PWM_DuCy_buff);
	dip204_write_data(0x25);
	x=xpos0+8;
	xprev=0;
	state = PWM_menu;
}

void f_PWM_menu(){
	dip204_set_cursor_position(xpos0+8,2);
	dip204_printf_string("%03d", PWM_frequency_buff);  
	dip204_set_cursor_position(xpos0+8,3);
	dip204_printf_string("%03d", PWM_DuCy_buff);  
	switch(PWM_modeselect[i]){
		//PWM_modeselect in LF mode
		case(0):																	
			if((JoystickRightFlag == 1) &&(x!=xpos0+10)){               //scroll right for 1 10 or 100 
			x++;
			clear_input_flags();
			}
			if((JoystickLeftFlag == 1) &&(x!=xpos0+8)){                 //scroll left for 1 10 or 100 
				x--;
				clear_input_flags();
			}
				if(JoystickUpFlag == 1){
			if (PWM_select == 0){
					Set_PWM_freq(1);									// 1 = opcode up, 0 = opcode down
				}
				if (PWM_select == 1){
					Set_PWM_DuCy(1);									// 1 = opcode up, 0 = opcode down
				}
				clear_input_flags();
			}
			if (JoystickDownFlag == 1){
				if (PWM_select == 0){
					Set_PWM_freq(0);									// 1 = opcode up, 0 = opcode down
				}
				if (PWM_select == 1){
					Set_PWM_DuCy(0);									// 1 = opcode up, 0 = opcode down
				}
				clear_input_flags();
			}
			if(PushButtonFlag_0 == 1){
				Set_PWM_Select();
				clear_input_flags();
			}
			if (xprev!=x){												//erase prev cursor and print new
				clearclutter(xprev,1);
				printmenu(x,1,0);
				xprev=x;
			}
			break;
		//PWM_modeselect in MF mode
		case(1):
			if(JoystickUpFlag == 1){
				if (PWM_select == 0){
					Set_PWM_freq_MF(1);									// 1 = opcode up, 0 = opcode down
				}
				if (PWM_select == 1){
					Set_PWM_DuCy(1);									// 1 = opcode up, 0 = opcode down
				}
				clear_input_flags();
			}
			if (JoystickDownFlag == 1){
				if (PWM_select == 0){
					Set_PWM_freq_MF(0);									// 1 = opcode up, 0 = opcode down
				}
				if (PWM_select == 1){
					Set_PWM_DuCy(0);									// 1 = opcode up, 0 = opcode down
				}
				clear_input_flags();
			}
			if(PushButtonFlag_0 == 1){
				Set_PWM_Select();
				clear_input_flags();
			}
			break;
		//PWM_modeselect in HF mode
		case(2):
			if(JoystickUpFlag == 1){
				if (PWM_select == 0)
				PWM_HF_frequency_state_pointer[i]++;
				PWM_HF_values();
				clear_input_flags();
			}
			if (JoystickDownFlag == 1){
				if (PWM_select == 0)
				PWM_HF_frequency_state_pointer[i]--;
				PWM_HF_values();
				clear_input_flags();
			}
			if(PushButtonFlag_0 == 1){
				Set_PWM_Select();
				clear_input_flags();
			}
			break;
		}
	if(PushButtonFlag_1 == 1){
		state = init_selection_menu;
		PWM_push_values();													//pushes PWM settings from buffer variables to live variables
		PWM_setter_update();												//updates PWM registers with new settings
		clear_input_flags();
	}
	if(PushButtonFlag_2 == 1){
		Set_PWM_mode();
		clear_input_flags();
	}

//	PWM_setter_update();
}


void Set_PWM_freq_MF(int opcode){											//sets frequencies for LF mode ranging from 1kHz to 100kHz, values between 10kHz and 100kHz are ranged in 10kHz steps
	if (opcode==1){															//opcode = 1 for adding
			if(PWM_frequency_buff<=90){      
				if(PWM_frequency_buff<=9){
					PWM_frequency_buff++;
				}          
				else {
					PWM_frequency_buff=PWM_frequency_buff+10;
				}
			}
	}
	if (opcode==0){															//opcode = 0 for substraction
		if(PWM_frequency_buff != 1){
			if(PWM_frequency_buff>10){                
				PWM_frequency_buff=PWM_frequency_buff-10;
			}
			else{
				PWM_frequency_buff--;
			}
		}
	}
}

void Set_PWM_freq(int opcode){												//sets frequencies for LF mode ranging from 1Hz to 999Hz
	if (opcode==1){															//opcode = 1 for adding
			if(x==xpos0+8&&PWM_frequency_buff<=899){						//add 100's, 10's or single digits based on cursor position
				PWM_frequency_buff=PWM_frequency_buff+100;
			}
			if(x==xpos0+9&&PWM_frequency_buff<=989){                
				PWM_frequency_buff=PWM_frequency_buff+10;
			}
			if(x==xpos0+10&&PWM_frequency_buff<=998){                   
				PWM_frequency_buff++;
			}
	}
	if (opcode==0){															//opcode = 0 for substraction
			if(x==xpos0+8&&PWM_frequency_buff>=101){						//substracts 100's, 10's or single digits based on cursor position
				PWM_frequency_buff=PWM_frequency_buff-100;
			}
			if(x==xpos0+9&&PWM_frequency_buff>=11){                
				PWM_frequency_buff=PWM_frequency_buff-10;
			}
			if(x==xpos0+10&&PWM_frequency_buff != 1){                   
				PWM_frequency_buff--;
			}
	}
}


void Set_PWM_DuCy(int opcode){
	if (opcode==1){
		if(PWM_DuCy_buff!=90){
			PWM_DuCy_buff=PWM_DuCy_buff+10;
		}
	}
	if (opcode==0){
		if(PWM_DuCy_buff!=10){
			PWM_DuCy_buff=PWM_DuCy_buff-10;
		}
	}
}


void Set_PWM_mode(){														//this function handles the changes that need to happen to change between LF, MF or HF mode
	static int PWM_freq_LF_mem = 100;										//buffer variables ending in _mem are used to remember the settings between the different modes
	static int PWM_freq_MF_mem = 10;
	static int PWM_freq_HF_mem = 1;
	static int PWM_DuCy_LF_mem = 50;
	static int PWM_DuCy_MF_mem = 50;
	switch (PWM_modeselect[i]){
		case(0):								//LF mode
			PWM_freq_LF_mem = PWM_frequency_buff;
			PWM_DuCy_LF_mem = PWM_DuCy_buff;
			PWM_modeselect[i] = 1;				//change to MF mode
			PWM_modifier_buff = 1000;
			PWM_DuCy_buff = PWM_DuCy_MF_mem;
			PWM_frequency_buff = PWM_freq_MF_mem;
		break;
		case(1):								//MF mode
			PWM_freq_MF_mem = PWM_frequency_buff;
			PWM_DuCy_MF_mem = PWM_DuCy_buff;
			PWM_modeselect[i] = 2;				//change to HF mode
			PWM_DuCy_buff = 50;
			PWM_HF_frequency_state_pointer[i] = PWM_freq_HF_mem;
			PWM_HF_values();
		break;
		case(2):								//HF mode
			PWM_freq_HF_mem = PWM_HF_frequency_state_pointer[i];
			PWM_modeselect[i] = 0;				//change to LF mode
			PWM_modifier_buff = 1;
			PWM_frequency_buff = PWM_freq_LF_mem;
			PWM_DuCy_buff = PWM_DuCy_LF_mem;
		break;
	}
	f_init_PWM_menu(0);
	//state = init_PWM_menu;
}

void Set_PWM_Select(){					//for dutycycle setting PWM_select = 1
	switch (PWM_select){				//for frequency setting PWM_select = 0
		case(0):
			PWM_select = 1;
			clearclutter(xpos0-4,2);
			clearclutter(xpos0+8,1);
			clearclutter(xpos0+9,1);
			clearclutter(xpos0+10,1);
			dip204_set_cursor_position(xpos0-4,3);
			dip204_printf_string("*");
			break;							
		case(1):
			PWM_select = 0;
			clearclutter(xpos0-4,3);
			dip204_set_cursor_position(xpos0-4,2);
			dip204_printf_string("*");
			break;
	}
}

void PWM_push_values(){														//pushes buffer values from PWM menu to live variables
	PWM_frequency[i] = PWM_frequency_buff;
	PWM_DutyCycle[i] = PWM_DuCy_buff;
	PWM_modifier[i] = PWM_modifier_buff;
}



void PWM_setter_update(){													//pushes parameters to PWM 
	int k;
	for (k=1;k!=5;k++){
		PWM_update(k-1, PWM_frequency[k]*PWM_modifier[k], PWM_DutyCycle[k]);
	}
}

void PWM_HF_values(){														//presets for HF mode frequencies
	switch(PWM_HF_frequency_state_pointer[i]){
		case (0):
			PWM_frequency_buff = 100;
			PWM_modifier_buff = 1000;
			break;
		case (1):
			PWM_frequency_buff = 200;
			PWM_modifier_buff = 1000;
			break;
		case (2):
			PWM_frequency_buff = 300;
			PWM_modifier_buff = 1000;
			break;
		case (3):
			PWM_frequency_buff = 400;
			PWM_modifier_buff = 1000;
			break;
		case (4):
			PWM_frequency_buff = 500;
			PWM_modifier_buff = 1000;
			break;
		case (5):
			PWM_frequency_buff = 600;
			PWM_modifier_buff = 1000;
			break;
		case (6):
			PWM_frequency_buff = 750;
			PWM_modifier_buff = 1000;
			break;
		case (7):
			PWM_frequency_buff = 1;
			PWM_modifier_buff = 1000000;
			break;
		case (8):
			PWM_frequency_buff = 2;
			PWM_modifier_buff = 1000000;
			break;
		case (9):
			PWM_frequency_buff = 3;
			PWM_modifier_buff = 1000000;
			break;
		case (10):
			PWM_frequency_buff = 4;
			PWM_modifier_buff = 1000000;
			break;
		case (11):
			PWM_frequency_buff = 6;
			PWM_modifier_buff = 1000000;
			break;
	}
	printmenu(17,2,4);
}


void debug_mode(){														//REMOVE BEFORE RELEASING PRODUCT
	if(JoystickLeftFlag == 1){									
		clear_input_flags();
		debugflag++;
		if (debugflag == 8){
			int k;
			tick_ms = (23*hh_const+59*mm_const+50*ss_const);
			pmillis = tick_ms;
			millis = 0;
			for (k=1;k!=5;k++){
				PWM_frequency[k]=10;
				PWM_DutyCycle[k]=50;
				PWM_modifier[k]=1000;
				triggerstart[k]=(23*hh_const+59*mm_const+15*ss_const);
				triggerstart[4]=(23*hh_const+59*mm_const+59*ss_const+999);
				triggerstart[1]=0;
				//triggerstop[k]=(23*hh_const+59*mm_const+55*ss_const);
				triggerstop[k]=(0*hh_const+1*mm_const+0*ss_const);
			}
			PWM_setter_update();	
			state = init_time_display;
		}
	}
}