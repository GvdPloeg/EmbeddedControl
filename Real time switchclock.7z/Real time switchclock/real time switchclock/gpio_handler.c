//The gpio_handler configures the buttons and joystick of the EVK1100
//in addition it handles the gpio interrupts
//to reduce time spent in interrupt, all gpio interrupts are handled by pulling their respective flag up



#include "stdint.h"
#include "compiler.h"
#include "board.h"
#include "gpio.h"
#include "gpio_handler.h"




void configure_push_buttons_IT(void)
{
	gpio_enable_pin_glitch_filter(PushButton_0);
	gpio_enable_pin_glitch_filter(PushButton_1);
	gpio_enable_pin_glitch_filter(PushButton_2);
	
	gpio_enable_pin_interrupt(PushButton_0, GPIO_RISING_EDGE);
	gpio_enable_pin_interrupt(PushButton_1 , GPIO_RISING_EDGE);
	gpio_enable_pin_interrupt(PushButton_2 , GPIO_RISING_EDGE);
	
	INTC_register_interrupt( &interrupt_handler, AVR32_GPIO_IRQ_0 + (PushButton_0/8), AVR32_INTC_INT1);
	INTC_register_interrupt( &interrupt_handler, AVR32_GPIO_IRQ_0 + (PushButton_1/8), AVR32_INTC_INT1);
	INTC_register_interrupt( &interrupt_handler, AVR32_GPIO_IRQ_0 + (PushButton_2/8), AVR32_INTC_INT1);
}

void configure_joystick_IT(void)
{
	gpio_enable_pin_glitch_filter(GPIO_JOYSTICK_UP);
	gpio_enable_pin_glitch_filter(GPIO_JOYSTICK_DOWN);
	gpio_enable_pin_glitch_filter(GPIO_JOYSTICK_RIGHT);
	//	gpio_enable_pin_glitch_filter(GPIO_JOYSTICK_PUSH);
	gpio_enable_pin_glitch_filter(GPIO_JOYSTICK_LEFT);
	
	gpio_enable_pin_interrupt(GPIO_JOYSTICK_UP , GPIO_FALLING_EDGE);
	gpio_enable_pin_interrupt(GPIO_JOYSTICK_DOWN , GPIO_FALLING_EDGE);
	gpio_enable_pin_interrupt(GPIO_JOYSTICK_RIGHT , GPIO_FALLING_EDGE);
	//	gpio_enable_pin_interrupt(GPIO_JOYSTICK_PUSH , GPIO_FALLING_EDGE);
	gpio_enable_pin_interrupt(GPIO_JOYSTICK_LEFT , GPIO_FALLING_EDGE);

	INTC_register_interrupt( &interrupt_handler, AVR32_GPIO_IRQ_0 + (GPIO_JOYSTICK_UP/8), AVR32_INTC_INT1);
	INTC_register_interrupt( &interrupt_handler, AVR32_GPIO_IRQ_0 + (GPIO_JOYSTICK_DOWN/8), AVR32_INTC_INT1);
	INTC_register_interrupt( &interrupt_handler, AVR32_GPIO_IRQ_0 + (GPIO_JOYSTICK_RIGHT/8), AVR32_INTC_INT1);
	//	INTC_register_interrupt( &interrupt_handler, AVR32_GPIO_IRQ_0 + (GPIO_JOYSTICK_PUSH/8), AVR32_INTC_INT1);
	INTC_register_interrupt( &interrupt_handler, AVR32_GPIO_IRQ_0 + (GPIO_JOYSTICK_LEFT/8), AVR32_INTC_INT1);
}


void interrupt_handler(void){
	if (gpio_get_pin_interrupt_flag(PushButton_0)){
		PushButtonFlag_0 = 1;
		gpio_clear_pin_interrupt_flag(PushButton_0);
	}
	if (gpio_get_pin_interrupt_flag(PushButton_1)){
		PushButtonFlag_1 = 1;
		gpio_clear_pin_interrupt_flag(PushButton_1);
	}
	if (gpio_get_pin_interrupt_flag(PushButton_2)){
		PushButtonFlag_2 = 1;
		gpio_clear_pin_interrupt_flag(PushButton_2);
	}
	if (gpio_get_pin_interrupt_flag(GPIO_JOYSTICK_DOWN)){
		JoystickDownFlag = 1;
		gpio_clear_pin_interrupt_flag(GPIO_JOYSTICK_DOWN);
	}
	if (gpio_get_pin_interrupt_flag(GPIO_JOYSTICK_UP)){
		JoystickUpFlag = 1;
		gpio_clear_pin_interrupt_flag(GPIO_JOYSTICK_UP);
	}
	if (gpio_get_pin_interrupt_flag(GPIO_JOYSTICK_RIGHT)){
		JoystickRightFlag = 1;
		gpio_clear_pin_interrupt_flag(GPIO_JOYSTICK_RIGHT);
	}
	if (gpio_get_pin_interrupt_flag(GPIO_JOYSTICK_LEFT)){
		JoystickLeftFlag = 1;
		gpio_clear_pin_interrupt_flag(GPIO_JOYSTICK_LEFT);
	}
	if (gpio_get_pin_interrupt_flag(GPIO_JOYSTICK_PUSH)){
		JoystickPushFlag = 1;
		gpio_clear_pin_interrupt_flag(GPIO_JOYSTICK_PUSH);
	}
}


void clear_input_flags(void){
	JoystickPushFlag = 0;
	JoystickDownFlag = 0;
	JoystickUpFlag = 0;
	JoystickRightFlag = 0;
	JoystickLeftFlag = 0;
	PushButtonFlag_0 = 0;
	PushButtonFlag_1 = 0;
	PushButtonFlag_2 = 0;
}
